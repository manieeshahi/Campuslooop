/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Users,
  Calendar,
  Gamepad2,
  Clock,
  Sparkles,
  BookOpen,
  Trophy,
  Check,
  ChevronRight,
  Flame,
  Zap,
  MapPin,
  Heart,
  MessageCircle,
  LogOut,
  Star,
  Search,
  Bell,
  Briefcase,
  Share2,
  ThumbsUp,
  Plus,
  Send,
  FileText,
  Bookmark,
  Award,
  Layers,
  GraduationCap,
  HelpCircle,
  ExternalLink,
  Code2,
  Cpu,
  CheckCircle2,
  X,
  Bot,
  CalendarDays,
  PenTool,
  RotateCcw,
  BookMarked,
  FlipHorizontal,
  Lightbulb,
  CreditCard,
  CheckSquare,
  Square,
  ArrowRight,
  UserCheck,
  Gift,
  Ticket,
  Tag,
  Copy,
  Coffee,
  Play,
  Pause,
  ShieldCheck,
  User,
  Compass,
  Settings,
  UserX,
  Edit3,
  Sliders,
  Sun,
  Moon,
} from 'lucide-react';

import clayStudent from './assets/images/clay_student_character_1793285125927.jpg';
import clayBobaStudy from './assets/images/clay_study_boba_1793285143665.jpg';
import trophyMascot from './assets/images/cartoon_quiz_trophy_1793284658081.jpg';
import campusSunsetBg from './assets/images/campus_students_dusk_1793294179785.jpg';

// Core Navigation Hubs
type MainHub = 'study' | 'notes' | 'tutors' | 'feed' | 'community' | 'profile';

// Sub-views
type StudySubView = 'matcher' | 'streak_timer' | 'room' | 'ai_solver' | 'planner';
type NotesSubView = 'marketplace' | 'flashcards' | 'tutors';
type TutorsSubView = 'browse' | 'become_tutor' | 'wallet';
type CommunitySubView = 'doubts' | 'teams' | 'quiz';

type SubjectType = 'DSA' | 'Java' | 'OS' | 'DBMS' | 'AI' | 'Flutter';
type MoodType = 'focus' | 'together' | 'advice';
type SlotType = 30 | 45 | 60;
type YearType = '1st Year' | '2nd Year' | '3rd Year' | '4th Year';

// Interfaces
interface Peer {
  id: string;
  n: string;
  username: string;
  avatarEmoji: string;
  avatarBg: string;
  college: string;
  branch: string;
  year: YearType;
  activity: string;
  bio: string;
  sk: string[];
  m: MoodType[];
  f: SlotType[];
  color: string;
  quote: string;
  rating: number;
  likesCount: number;
  isLiked?: boolean;
  isConnected?: boolean;
  leetcodeSolved?: number;
  vouchersCount?: number;
  activeStory?: {
    topic: string;
    timeLeft: string;
    statusBadge: string;
  };
  s?: number;
  why?: string[];
}

interface Tutor {
  id: string;
  name: string;
  avatarEmoji: string;
  year: string;
  specialty: SubjectType[];
  rating: number;
  reviewsCount: number;
  sessionsCompleted: number;
  hourlyPoints: number;
  badge: string;
  bio: string;
  availableSlots: string[];
}

interface NoteItem {
  id: string;
  title: string;
  subject: SubjectType;
  author: string;
  authorYear: string;
  rating: number;
  reviews: number;
  downloads: number;
  pages: number;
  summary: string[];
  formulas: string[];
  flashcards: { q: string; a: string }[];
}

interface PlannedDay {
  day: string;
  subject: SubjectType;
  topic: string;
  duration: string;
  completed: boolean;
  type: 'concept' | 'problems' | 'revision';
}

interface CommunityPost {
  id: string;
  author: string;
  authorYear: string;
  avatarEmoji: string;
  subject: SubjectType;
  title: string;
  desc: string;
  upvotes: number;
  hasUpvoted?: boolean;
  replies: {
    author: string;
    text: string;
    isVerifiedHelpful?: boolean;
    time: string;
  }[];
  resourceTitle?: string;
  time: string;
}

interface CampusEvent {
  id: number;
  t: string;
  title: string;
  where: string;
  going: number;
  tag: 'Hackathon' | 'Workshop' | 'Internship' | 'Deadline' | 'Contest';
  eligibility: string;
  organizer: string;
  logoType?: 'sih' | 'tcs' | 'google' | 'flipkart' | 'codesprint' | 'workshop' | 'contest' | 'acm';
  prizePool?: string;
  deadline?: string;
  tagBg: string;
  tagColor: string;
}

interface MeetingRoom {
  id: string;
  name: string;
  subject: SubjectType;
  code: string;
  time: string;
  duration: string;
  topic: string;
  tutor?: {
    name: string;
    role: string;
    avatarEmoji: string;
    rating: number;
  };
  mutualBuddies: {
    name: string;
    avatarEmoji: string;
    avatarBg: string;
  }[];
  participantsCount: number;
  maxParticipants: number;
  isLive: boolean;
}

interface ProjectTeam {
  id: string;
  hackathonName: string;
  logoType: 'sih' | 'tcs' | 'google' | 'flipkart';
  title: string;
  event: string;
  desc: string;
  creator: string;
  creatorYear: string;
  membersCount: number;
  maxMembers: number;
  eligibility: string;
  location: string;
  prizePool: string;
  deadline: string;
  rolesNeeded: string[];
  appliedRoles?: string[];
  applied?: boolean;
}

function HackathonLogo({ type }: { type: 'sih' | 'tcs' | 'google' | 'flipkart' | 'codesprint' | 'workshop' | 'contest' | 'acm' }) {
  if (type === 'tcs') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0B2545] to-[#134074] p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center text-white shrink-0">
        <span className="text-[11px] font-black tracking-widest text-white leading-none">TCS</span>
        <span className="text-[9px] font-extrabold text-sky-300 leading-none mt-0.5">iON</span>
      </div>
    );
  }
  if (type === 'sih') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF9933] via-white to-[#138808] p-0.5 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center shrink-0">
        <div className="w-full h-full bg-[#190019]/90 rounded-[14px] flex flex-col items-center justify-center text-white p-0.5">
          <span className="text-[10px] font-black text-amber-300 leading-none">SIH</span>
          <span className="text-[8px] font-bold text-white leading-none mt-0.5">2026</span>
        </div>
      </div>
    );
  }
  if (type === 'google') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-white p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center shrink-0">
        <div className="flex items-center gap-0.5">
          <span className="text-xs font-black text-[#4285F4]">G</span>
          <span className="text-xs font-black text-[#EA4335]">D</span>
          <span className="text-xs font-black text-[#FBBC05]">S</span>
          <span className="text-xs font-black text-[#34A853]">C</span>
        </div>
        <span className="text-[8px] font-black text-[#522B5B] uppercase leading-none mt-0.5">Solutions</span>
      </div>
    );
  }
  if (type === 'flipkart') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-[#2874F0] p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center text-white shrink-0">
        <span className="text-[10px] font-black text-[#FFE500] leading-none">Flipkart</span>
        <span className="text-[8px] font-extrabold text-white leading-none mt-0.5">GRiD 7.0</span>
      </div>
    );
  }
  if (type === 'workshop') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-800 p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center text-white shrink-0">
        <Sparkles className="w-5 h-5 text-emerald-200" />
        <span className="text-[7.5px] font-black uppercase text-white leading-none mt-0.5">WORKSHOP</span>
      </div>
    );
  }
  if (type === 'contest') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-700 to-indigo-900 p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center text-white shrink-0">
        <Trophy className="w-5 h-5 text-amber-300" />
        <span className="text-[7.5px] font-black uppercase text-amber-200 leading-none mt-0.5">CF DUEL</span>
      </div>
    );
  }
  if (type === 'acm') {
    return (
      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-rose-700 to-red-900 p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center text-white shrink-0">
        <Code2 className="w-5 h-5 text-white" />
        <span className="text-[7.5px] font-black uppercase text-white leading-none mt-0.5">ICPC</span>
      </div>
    );
  }
  return (
    <div className="w-12 h-12 rounded-2xl bg-[#522B5B] p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center text-white shrink-0">
      <Code2 className="w-5 h-5 text-[#DFB6B2]" />
      <span className="text-[8px] font-black text-white leading-none mt-0.5">CODE</span>
    </div>
  );
}

interface StudyVoucher {
  id: string;
  title: string;
  category: 'food' | 'books' | 'tech' | 'stationery';
  partner: string;
  discount: string;
  sparksCost: number;
  promoCode: string;
  description: string;
  iconEmoji: string;
  logoBrand?: 'spotify' | 'epson' | 'pw' | 'starbucks' | 'notion' | 'canteen' | 'books';
  badge?: string;
  validity: string;
  claimed?: boolean;
}

function VoucherBrandLogo({ brand, emoji }: { brand?: string; emoji: string }) {
  if (brand === 'spotify') {
    return (
      <div className="w-11 h-11 rounded-2xl bg-[#1DB954] p-1.5 shadow-md border-2 border-white flex items-center justify-center shrink-0">
        <svg className="w-6 h-6 text-black fill-current" viewBox="0 0 24 24">
          <path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
        </svg>
      </div>
    );
  }
  if (brand === 'epson') {
    return (
      <div className="w-11 h-11 rounded-2xl bg-[#003399] p-1 shadow-md border-2 border-white flex flex-col items-center justify-center text-white shrink-0">
        <span className="text-[10px] font-black tracking-wider leading-none">EPSON</span>
        <span className="text-[7px] font-extrabold text-sky-200 leading-none mt-0.5">EcoPrint</span>
      </div>
    );
  }
  if (brand === 'pw') {
    return (
      <div className="w-11 h-11 rounded-2xl bg-[#111111] p-1 shadow-md border-2 border-[#DFB6B2] flex flex-col items-center justify-center shrink-0">
        <div className="flex items-center gap-0.5">
          <span className="text-sm font-black text-white leading-none">P</span>
          <span className="text-sm font-black text-[#FF3E3E] leading-none">W</span>
        </div>
        <span className="text-[7px] font-black text-amber-300 uppercase leading-none mt-0.5">Campus</span>
      </div>
    );
  }
  if (brand === 'starbucks') {
    return (
      <div className="w-11 h-11 rounded-2xl bg-[#00704A] p-1 shadow-md border-2 border-white flex flex-col items-center justify-center text-white shrink-0">
        <span className="text-xs">⭐</span>
        <span className="text-[7px] font-black tracking-tighter leading-none mt-0.5 text-white">STARBUCKS</span>
      </div>
    );
  }
  if (brand === 'notion') {
    return (
      <div className="w-11 h-11 rounded-2xl bg-white p-1 shadow-md border-2 border-slate-300 flex flex-col items-center justify-center shrink-0">
        <span className="text-sm font-black text-black">N</span>
        <span className="text-[7px] font-black text-slate-500 uppercase leading-none">Notion</span>
      </div>
    );
  }
  return (
    <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#FBE4D8] to-[#DFB6B2] flex items-center justify-center text-xl shrink-0 shadow-sm border border-white">
      {emoji}
    </div>
  );
}

const SUBJECTS: SubjectType[] = ['DSA', 'Java', 'OS', 'DBMS', 'AI', 'Flutter'];

const MOODS: { id: MoodType; label: string; emoji: string }[] = [
  { id: 'focus', label: 'Deep Focus', emoji: '🎧' },
  { id: 'together', label: 'Study Together', emoji: '🤝' },
  { id: 'advice', label: 'Need Advice', emoji: '💡' },
];

const CARTOON_AVATARS = [
  { id: 'clay_mascot', name: 'Clay Mascot 3D', src: '/assets/aistudio/image_bfa36e2d.png', emoji: '🦊' },
  { id: 'clay_student', name: 'Clay Student', src: clayStudent, emoji: '🎓' },
  { id: 'bunny_reader', name: 'Study Bunny', src: '/assets/aistudio/image_1a4f2b80.png', emoji: '🐰' },
  { id: 'boba_study', name: 'Boba Learner', src: clayBobaStudy, emoji: '🧋' },
  { id: 'trophy_mascot', name: 'Quiz Trophy', src: trophyMascot, emoji: '🏆' },
];

const PEERS: Peer[] = [
  {
    id: 'p1',
    n: 'Riya Sharma',
    username: '@riya_codes',
    avatarEmoji: '🌸',
    avatarBg: 'bg-rose-100',
    college: 'Delhi Technological University (DTU)',
    branch: '3rd Year · Computer Science & Eng.',
    year: '3rd Year',
    activity: '🔥 In Central Library: Practicing Graph BFS/DFS & Dynamic Programming',
    bio: 'DTU CSE \'27 | Solved 450+ LeetCode problems | Smart India Hackathon finalist | Looking for a study buddy for Trees & Java backend prep! 🌸',
    sk: ['DSA', 'Java', 'OS'],
    m: ['together', 'advice'],
    f: [30, 45, 60],
    color: '#DFB6B2',
    quote: 'Solving Trees & Graphs on LeetCode today!',
    rating: 4.9,
    likesCount: 184,
    isConnected: true,
    activeStory: {
      topic: 'Practicing LeetCode Hard Trees',
      timeLeft: '2h left',
      statusBadge: 'Library 📚',
    },
  },
  {
    id: 'p2',
    n: 'Aarav Patel',
    username: '@aarav.dev',
    avatarEmoji: '🌿',
    avatarBg: 'bg-emerald-100',
    college: 'BITS Pilani, Goa Campus',
    branch: '2nd Year · Information Technology',
    year: '2nd Year',
    activity: '🚀 Building Flutter E-Commerce UI & Riverpod State Management',
    bio: 'BITS Goa \'28 | Flutter & Firebase enthusiast | TCS-iON Hackathon contestant | Free for 45 min peer code review and mock battles! 🌿',
    sk: ['Flutter', 'DBMS', 'Java'],
    m: ['focus', 'together'],
    f: [30, 45],
    color: '#D1E7DD',
    quote: 'Flutter State Management & SQLite caching.',
    rating: 4.8,
    likesCount: 142,
    isConnected: true,
    activeStory: {
      topic: 'Debugging Riverpod state cache',
      timeLeft: '45m left',
      statusBadge: 'Hostel Lab 💻',
    },
  },
  {
    id: 'p3',
    n: 'Meera Sen',
    username: '@meera_ai',
    avatarEmoji: '🪴',
    avatarBg: 'bg-amber-100',
    college: 'IIT Roorkee',
    branch: '3rd Year · AI & Data Science',
    year: '3rd Year',
    activity: '🧠 Training PyTorch Transformer model & SQL query optimization',
    bio: 'IITR \'27 | Kaggle Master & AI researcher | Working on crop diagnosis with Gemini API | Let\'s crack semester exams together! 🪴',
    sk: ['AI', 'DBMS', 'DSA'],
    m: ['advice'],
    f: [45, 60],
    color: '#F8D7DA',
    quote: 'PyTorch model training & SQL optimization.',
    rating: 5.0,
    likesCount: 219,
    activeStory: {
      topic: 'Fine-tuning LoRA weights in lab',
      timeLeft: '1h left',
      statusBadge: 'AI Lab 🧠',
    },
  },
  {
    id: 'p4',
    n: 'Kabir Verma',
    username: '@kabir_os',
    avatarEmoji: '⚡',
    avatarBg: 'bg-sky-100',
    college: 'Netaji Subhas Univ. of Tech (NSUT)',
    branch: '4th Year · Electronics & Comm.',
    year: '4th Year',
    activity: '⚡ Grinding OS CPU Scheduling, Deadlocks & Concurrency sem prep',
    bio: 'NSUT \'26 | Core Systems & Embedded C++ geek | 9.1 CGPA | Peer Tutor on CampusLoop | DM for OS & Hardware doubt solving! ⚡',
    sk: ['OS', 'DSA', 'Java'],
    m: ['focus'],
    f: [60],
    color: '#FFF3CD',
    quote: 'Concurrency, deadlocks & memory management.',
    rating: 4.9,
    likesCount: 198,
    isConnected: true,
    activeStory: {
      topic: 'Explaining Banker\'s Algorithm on Pod',
      timeLeft: '30m left',
      statusBadge: 'Study Pod 🎧',
    },
  },
  {
    id: 'p5',
    n: 'Tanya Joshi',
    username: '@tanya.ui',
    avatarEmoji: '✨',
    avatarBg: 'bg-purple-100',
    college: 'IIT Delhi',
    branch: '3rd Year · Design & Computing',
    year: '3rd Year',
    activity: '🎨 Designing Figma 3D Clay Prototypes & Flipkart GRiD wireframes',
    bio: 'IITD \'27 | UI/UX Designer & Frontend Dev | Loves Claymorphic aesthetics | Seeking a backend partner for college hackathons! ✨',
    sk: ['Flutter', 'AI', 'DSA'],
    m: ['together'],
    f: [30, 45],
    color: '#E2D9F3',
    quote: 'Figma Claymorphism & Interaction Design.',
    rating: 4.9,
    likesCount: 165,
    activeStory: {
      topic: 'Working on hackathon presentation deck',
      timeLeft: '3h left',
      statusBadge: 'Cafeteria ☕',
    },
  },
];

const TUTORS: Tutor[] = [
  {
    id: 'tut1',
    name: 'Riya Sharma',
    avatarEmoji: '🌸',
    year: '3rd Year CSE',
    specialty: ['DSA', 'Java'],
    rating: 4.9,
    reviewsCount: 38,
    sessionsCompleted: 45,
    hourlyPoints: 50,
    badge: 'Gold DSA Mentor',
    bio: 'Solved 450+ LeetCode problems. Specialized in Binary Search, Graphs & DP.',
    availableSlots: ['Today 5:00 PM', 'Tomorrow 6:30 PM', 'Sunday 11:00 AM'],
  },
  {
    id: 'tut2',
    name: 'Kabir Verma',
    avatarEmoji: '⚡',
    year: '4th Year ECE',
    specialty: ['OS', 'DSA'],
    rating: 5.0,
    reviewsCount: 29,
    sessionsCompleted: 32,
    hourlyPoints: 45,
    badge: 'System Systems Pro',
    bio: 'Scored A+ in Operating Systems. Master of Paging, Semaphores & CPU Scheduling.',
    availableSlots: ['Today 7:00 PM', 'Saturday 4:00 PM'],
  },
  {
    id: 'tut3',
    name: 'Aarav Patel',
    avatarEmoji: '🌿',
    year: '2nd Year IT',
    specialty: ['Flutter', 'DBMS'],
    rating: 4.8,
    reviewsCount: 22,
    sessionsCompleted: 26,
    hourlyPoints: 40,
    badge: 'App Development Lead',
    bio: 'Built 4 production Flutter apps. Great at SQL Normalization & Schema Design.',
    availableSlots: ['Tomorrow 4:00 PM', 'Sunday 2:00 PM'],
  },
];

const NOTES_LIBRARY: NoteItem[] = [
  {
    id: 'n1',
    title: 'Complete DSA Visual Handwritten Notes',
    subject: 'DSA',
    author: 'Riya Sharma',
    authorYear: '3rd Year',
    rating: 4.9,
    reviews: 64,
    downloads: 380,
    pages: 42,
    summary: [
      'Comprehensive coverage of Arrays, Two-Pointer, Sliding Window & Binary Search.',
      'Step-by-step visual diagrams for Tree Traversals (Inorder, Preorder, Level-Order).',
      'Dynamic Programming 0/1 Knapsack patterns with memoization vs tabulation tables.',
    ],
    formulas: [
      'Binary Search: mid = low + (high - low) / 2',
      'Tree Height: 1 + max(height(left), height(right))',
      'QuickSort Average Time: O(n log n), Worst: O(n²)',
    ],
    flashcards: [
      {
        q: 'What is the worst-case time complexity of QuickSort?',
        a: 'O(n²), occurring when the chosen pivot is always the smallest or largest element.',
      },
      {
        q: 'What data structure is used for Breadth-First Search (BFS)?',
        a: 'A Queue (FIFO) is used to visit vertices level by level.',
      },
      {
        q: 'How does an AVL Tree maintain balance?',
        a: 'By tracking Balance Factor = Height(Left) - Height(Right), keeping it within {-1, 0, 1} using LL, RR, LR, RL rotations.',
      },
    ],
  },
  {
    id: 'n2',
    title: 'Operating Systems End-Sem Master Cheat Sheet',
    subject: 'OS',
    author: 'Kabir Verma',
    authorYear: '4th Year',
    rating: 5.0,
    reviews: 48,
    downloads: 410,
    pages: 28,
    summary: [
      'CPU Scheduling Algorithms with Gantt charts: FCFS, SJF, Round Robin & Priority.',
      'Banker’s Algorithm for Deadlock Avoidance with Safety Matrix determination.',
      'Virtual Memory: Page Fault calculation for FIFO, LRU, and Optimal Page Replacement.',
    ],
    formulas: [
      'Turnaround Time = Completion Time - Arrival Time',
      'Waiting Time = Turnaround Time - Burst Time',
      'Need Matrix = Max Demand - Allocation',
    ],
    flashcards: [
      {
        q: 'What are the 4 Coffman conditions for a deadlock?',
        a: '1. Mutual Exclusion, 2. Hold and Wait, 3. No Preemption, 4. Circular Wait.',
      },
      {
        q: 'What is Belady’s Anomaly in Paging?',
        a: 'The phenomenon where increasing the number of page frames results in more page faults (seen in FIFO replacement).',
      },
      {
        q: 'What is the purpose of the Translation Lookaside Buffer (TLB)?',
        a: 'A high-speed hardware cache for fast virtual-to-physical address translation.',
      },
    ],
  },
  {
    id: 'n3',
    title: 'Java OOP & Spring Boot JPA Architecture',
    subject: 'Java',
    author: 'Aarav Patel',
    authorYear: '2nd Year',
    rating: 4.8,
    reviews: 35,
    downloads: 290,
    pages: 35,
    summary: [
      'Core OOP Principles (Encapsulation, Inheritance, Polymorphism, Abstraction) with real-world examples.',
      'Collections Framework: ArrayList vs LinkedList, HashMap internal collision buckets.',
      'Spring Boot JPA: Resolving N+1 queries with @EntityGraph and JOIN FETCH.',
    ],
    formulas: [
      'HashMap Load Factor: default 0.75 threshold',
      'Java Memory: Stack (Primitives & References) vs Heap (Objects)',
      'Concurrency: ConcurrentHashMap uses synchronized bin buckets',
    ],
    flashcards: [
      {
        q: 'Why is String immutable in Java?',
        a: 'For Security, Thread Safety, String Pool caching efficiency, and HashMap key reliability.',
      },
      {
        q: 'How does HashMap handle hash collisions in Java 8+?',
        a: 'Uses linked list chains, converting to balanced Red-Black Trees when bucket size exceeds 8 (TREEIFY_THRESHOLD).',
      },
      {
        q: 'What is the difference between Comparable and Comparator?',
        a: 'Comparable provides natural single-order sorting (compareTo), while Comparator allows multiple custom sort strategies (compare).',
      },
    ],
  },
];

const INITIAL_EVENTS: CampusEvent[] = [
  {
    id: 1,
    t: 'Nov 15 · Online Round',
    title: 'TCS-iON Hackathon: Digital Ninja Challenge',
    where: 'Online Phase + TCS Siruseri Grand Finale',
    going: 240,
    tag: 'Hackathon',
    eligibility: 'B.Tech / BE Students (2nd, 3rd & 4th Year) · All Branches',
    organizer: 'Tata Consultancy Services & TCS-iON',
    logoType: 'tcs',
    prizePool: '₹5,00,000 + Fast-Track Digital Ninja Interview',
    deadline: 'Registration closes Nov 15, 2026',
    tagBg: 'bg-[#0B2545]/10',
    tagColor: 'text-[#0B2545]',
  },
  {
    id: 2,
    t: 'Nov 30 · Grand Finale',
    title: 'Smart India Hackathon 2026 (SIH)',
    where: 'AICTE Nodal Centers & Hybrid Finals',
    going: 380,
    tag: 'Hackathon',
    eligibility: 'All Engineering Batches (Team of 6 with 1+ Female Member)',
    organizer: 'Ministry of Education & AICTE',
    logoType: 'sih',
    prizePool: '₹1,00,000 per Problem Statement',
    deadline: 'Idea Submission closes Nov 30, 2026',
    tagBg: 'bg-orange-50',
    tagColor: 'text-orange-700',
  },
  {
    id: 3,
    t: 'Dec 15 · Global Showcase',
    title: 'Google Solution Challenge 2026',
    where: 'Virtual Showcase + Google Campus Live Demo',
    going: 195,
    tag: 'Hackathon',
    eligibility: 'Open to All Students with GDSC Membership',
    organizer: 'Google Developer Student Clubs',
    logoType: 'google',
    prizePool: '$4,000 per Member + Google Engineer Mentorship',
    deadline: 'Project Submission closes Dec 15, 2026',
    tagBg: 'bg-blue-50',
    tagColor: 'text-blue-700',
  },
  {
    id: 4,
    t: 'Nov 20 · Round 1 Live',
    title: 'Flipkart GRiD 7.0 - E-Commerce Tech & Robotics',
    where: 'Online Rounds + Flipkart HQ Bengaluru Finale',
    going: 310,
    tag: 'Hackathon',
    eligibility: 'Engineering Batches 2026, 2027 & 2028 (B.Tech / B.E. / M.Tech)',
    organizer: 'Flipkart Campus Talent Team',
    logoType: 'flipkart',
    prizePool: '₹5,25,000 + PPI for SDE-1 / SDE-2 (CTC ₹32 LPA)',
    deadline: 'Registrations close Nov 20, 2026',
    tagBg: 'bg-sky-50',
    tagColor: 'text-sky-800',
  },
  {
    id: 5,
    t: 'Nov 22 · Hands-on Lab',
    title: 'Generative AI & LLMs: Building RAG Agents Masterclass',
    where: 'Auditorium 2 + Live Streamed Discord Lab',
    going: 315,
    tag: 'Workshop',
    eligibility: 'Open to all Engineering Students (Bring Laptops)',
    organizer: 'Google Developer Student Clubs & Campus AI Wing',
    logoType: 'workshop',
    prizePool: 'Free $100 Cloud API Credits + Verifiable Credential',
    deadline: 'Limited to 60 In-Person Seats',
    tagBg: 'bg-emerald-50',
    tagColor: 'text-emerald-800',
  },
  {
    id: 6,
    t: 'Nov 28 · 3 Hours Sprint',
    title: 'CodeForces Intra-College Winter Sprint 2026',
    where: 'Central Computer Center Labs 1 & 2',
    going: 420,
    tag: 'Contest',
    eligibility: '1st to 4th Year Individual Coders (All Branches)',
    organizer: 'Competitive Programming Society DTU',
    logoType: 'contest',
    prizePool: '₹35,000 Cash Pool + Top 10 Swag Kits & Hoodies',
    deadline: 'Rated Contest · Closes Nov 27, 2026',
    tagBg: 'bg-purple-50',
    tagColor: 'text-purple-800',
  },
  {
    id: 7,
    t: 'Dec 05 · Weekend Intensive',
    title: 'Full-Stack System Design & Distributed Microservices',
    where: 'Seminar Hall B + High-Throughput GitHub Lab',
    going: 265,
    tag: 'Workshop',
    eligibility: '2nd, 3rd & 4th Year CS/IT/ECE Students',
    organizer: 'CampusLoop Alumni Tech Leaders',
    logoType: 'workshop',
    prizePool: 'Architect Certificate + Senior Mock Interview Slot',
    deadline: 'Registrations close Dec 03, 2026',
    tagBg: 'bg-amber-50',
    tagColor: 'text-amber-800',
  },
  {
    id: 8,
    t: 'Dec 12 · 5 Hours Duel',
    title: 'ACM-ICPC Regional Mock Qualifier Duel',
    where: 'Online on HackerRank & CodeChef Portal',
    going: 350,
    tag: 'Contest',
    eligibility: 'Teams of 3 registered college students',
    organizer: 'ACM Student Chapter & Algorithms Club',
    logoType: 'acm',
    prizePool: '₹50,000 Travel Sponsorship to ICPC Regional Finals',
    deadline: 'Team Registration closes Dec 10, 2026',
    tagBg: 'bg-rose-50',
    tagColor: 'text-rose-800',
  },
];

const INITIAL_TEAMS: ProjectTeam[] = [
  {
    id: 't_tcs',
    hackathonName: 'TCS-iON Hackathon',
    logoType: 'tcs',
    title: 'CloudVault: Secure FinTech Microservices & Fraud AI',
    event: 'TCS-iON HACKATHON',
    desc: 'Developing an AI-driven real-time UPI transaction fraud detection engine with sub-10ms response time using Apache Kafka and Spring Boot.',
    creator: 'Aditya Nair (3rd Year)',
    creatorYear: '3rd Year CSE',
    membersCount: 2,
    maxMembers: 4,
    eligibility: 'B.Tech / BE Students (2nd, 3rd & 4th Year) · All Branches',
    location: 'Phase 1: Online · Grand Finale: TCS Siruseri / Regional Hub',
    prizePool: '₹5,00,000 Prize Pool + Fast-Track Digital Ninja Interview',
    deadline: 'Nov 15, 2026',
    rolesNeeded: ['Spring Boot Backend', 'Python / ML Dev', 'React UI Specialist'],
  },
  {
    id: 't_sih',
    hackathonName: 'Smart India Hackathon 2026 (SIH)',
    logoType: 'sih',
    title: 'EduSphere: AI-Powered Adaptive Tutor',
    event: 'SMART INDIA HACKATHON 2026',
    desc: 'Building an interactive AI platform that transforms lecture slides into interactive quizzes, concept flashcards, and student study pods.',
    creator: 'Rohan Gupta (3rd Year)',
    creatorYear: '3rd Year CSE',
    membersCount: 2,
    maxMembers: 4,
    eligibility: 'All AICTE Approved Batches (Team of 6 with 1+ Female Member)',
    location: 'Nodal Centers Across India (Hybrid Finals)',
    prizePool: '₹1,00,000 per Problem Statement by Ministry of Education',
    deadline: 'Idea Submission: Nov 30, 2026',
    rolesNeeded: ['Java Backend', 'Flutter Frontend', 'UI/UX Designer'],
  },
  {
    id: 't_google',
    hackathonName: 'Google Solution Challenge 2026',
    logoType: 'google',
    title: 'AgroSense: AI Crop Disease & Local Weather Advisory',
    event: 'GOOGLE SOLUTION CHALLENGE',
    desc: 'Mobile-first computer vision model running on Gemini Nano + Flutter for offline crop leaf infection diagnosis for rural farmers.',
    creator: 'Ananya Sharma (3rd Year)',
    creatorYear: '3rd Year IT',
    membersCount: 3,
    maxMembers: 4,
    eligibility: 'College Students with Google Developer Student Club Membership',
    location: 'Global Virtual Showcase + Google Campus Live Demo',
    prizePool: '$4,000 per Team Member + Mentorship by Google Engineers',
    deadline: 'Project Submission: Dec 15, 2026',
    rolesNeeded: ['TensorFlow / Gemini API', 'Flutter Dev'],
  },
  {
    id: 't_flipkart',
    hackathonName: 'Flipkart GRiD 7.0 - E-Commerce Tech',
    logoType: 'flipkart',
    title: 'WarehouseFlow: Autonomous AMR Path Optimization',
    event: 'FLIPKART GRID 7.0',
    desc: 'Simulating fleet coordination of 50+ automated mobile robots in high-density fulfillment centers using multi-agent reinforcement learning.',
    creator: 'Vikram Rao (4th Year)',
    creatorYear: '4th Year ECE',
    membersCount: 2,
    maxMembers: 3,
    eligibility: 'Engineering Batches 2026, 2027 & 2028 (B.Tech / B.E. / M.Tech)',
    location: 'Round 1-3 Online · National Grand Finale at Flipkart HQ Bengaluru',
    prizePool: '₹5,25,000 + PPI for SDE-1 / SDE-2 (CTC ₹32 LPA)',
    deadline: 'Registrations close Nov 20, 2026',
    rolesNeeded: ['Python / ROS Dev', 'Algorithms / C++ Dev'],
  },
];

const INITIAL_COMMUNITY: CommunityPost[] = [
  {
    id: 'c1',
    author: 'Devansh Roy',
    authorYear: '2nd Year CSE',
    avatarEmoji: '⚡',
    subject: 'DSA',
    title: 'Intuitive way to handle Red-Black Tree deletion double-black case?',
    desc: 'I keep getting confused between Case 2 (sibling is black with black children) and Case 3 (sibling has red child). Need a clean mental model.',
    upvotes: 24,
    time: '2 hours ago',
    replies: [
      {
        author: 'Riya Sharma (3rd Year)',
        text: 'Think of the double-black as an extra heavy token that needs to be absorbed. A rotation with the sibling transfers the red color and absorbs the token immediately! See note #1.',
        isVerifiedHelpful: true,
        time: '1 hour ago',
      },
    ],
    resourceTitle: 'Red-Black Trees Cheatsheet.pdf',
  },
];

const INITIAL_VOUCHERS: StudyVoucher[] = [
  {
    id: 'v_starbucks',
    title: 'Starbucks 40% Off Cold Brew & Frappuccino',
    category: 'food',
    partner: 'Starbucks Coffee (Campus Outlet)',
    discount: '40% OFF',
    sparksCost: 150,
    promoCode: 'STARBUCKS-JAVA40',
    description: 'Recharge late-night study sessions! Valid on Java Chip Frappuccino, Vanilla Cold Brew & Butter Croissants.',
    iconEmoji: '☕',
    logoBrand: 'starbucks',
    badge: 'Campus Favorite',
    validity: 'Valid till Nov 20',
  },
  {
    id: 'v_spotify',
    title: 'Spotify Student Premium 3 Months ₹99',
    category: 'tech',
    partner: 'Spotify Campus Pack',
    discount: '₹99 ONLY',
    sparksCost: 180,
    promoCode: 'SPOTIFY-LOFI-PASS',
    description: 'Ad-free study beats, deep work ambient sounds, and offline podcasts for study focus with zero ad breaks.',
    iconEmoji: '🎧',
    logoBrand: 'spotify',
    badge: 'Best Value',
    validity: 'Valid for students',
  },
  {
    id: 'v_epson',
    title: 'Epson EcoTank 50 Free Laser Color Pages',
    category: 'stationery',
    partner: 'Epson Campus Print Station (Admin Block)',
    discount: '100% FREE',
    sparksCost: 90,
    promoCode: 'EPSON-PRINT-FREE50',
    description: 'Print major project reports, IEEE research papers, and lab manuals in high-res color with free spiral binding.',
    iconEmoji: '🖨️',
    logoBrand: 'epson',
    badge: 'Popular',
    validity: 'Valid this semester',
  },
  {
    id: 'v_pw',
    title: 'Physics Wallah (PW) - 40% Off Tech Batches',
    category: 'tech',
    partner: 'Physics Wallah (PW) Campus Partner',
    discount: '40% OFF',
    sparksCost: 200,
    promoCode: 'PW-CAMPUS-TECH40',
    description: 'Flat 40% off on PW GATE CS/IT, DSA Placement Batch, System Design masterclass & full-length mock test series.',
    iconEmoji: '🎓',
    logoBrand: 'pw',
    badge: 'Top Exam Prep',
    validity: 'Valid till Nov 30',
  },
  {
    id: 'v_canteen',
    title: '50% Off Adrak Chai & Crispy Samosa Combo',
    category: 'food',
    partner: 'Central Campus Canteen',
    discount: '50% OFF',
    sparksCost: 100,
    promoCode: 'CANTEEN-CHAI50',
    description: 'Post-study refresh! Valid on hot ginger adrak chai + 2 crispy aloo samosas at Central Canteen counter.',
    iconEmoji: '🥟',
    logoBrand: 'canteen',
    badge: 'Hot Deal',
    validity: 'Valid till Nov 15',
  },
  {
    id: 'v_notion',
    title: '3 Months Notion AI Pro Student Pass',
    category: 'tech',
    partner: 'Notion Education Partner',
    discount: 'FREE PRO',
    sparksCost: 250,
    promoCode: 'NOTION-STUDENT-PRO',
    description: 'Organize exam roadmaps, subject wikis, and lecture notes with unlimited AI summaries and study planner.',
    iconEmoji: '💻',
    logoBrand: 'notion',
    badge: 'Exclusive',
    validity: 'Redeem anytime',
  },
  {
    id: 'v_books',
    title: '₹150 Flat Off Engineering Reference Books',
    category: 'books',
    partner: 'University Book Depo & Co.',
    discount: '₹150 OFF',
    sparksCost: 160,
    promoCode: 'CAMPUS-READ150',
    description: 'Valid on Cormen DSA, Galvin OS, or semester previous year solved question banks.',
    iconEmoji: '📚',
    logoBrand: 'books',
    badge: 'Top Pick',
    validity: 'Valid till Nov 30',
  },
];

const INITIAL_ROOMS: MeetingRoom[] = [
  {
    id: 'room-1',
    name: 'DSA Graphs & Dynamic Programming Pod',
    subject: 'DSA',
    code: 'LOOP-DSA4',
    time: 'Live Now · Started 15m ago',
    duration: '45 mins sprint',
    topic: 'Graph BFS/DFS, Dijkstra & Memoization Patterns',
    tutor: {
      name: 'Aman Verma',
      role: '4th Year DSA Mentor (Ex-Amazon Intern)',
      avatarEmoji: '👨‍💻',
      rating: 4.95,
    },
    mutualBuddies: [
      { name: 'Priya Sharma', avatarEmoji: '🌸', avatarBg: 'bg-rose-100' },
      { name: 'Aarav Patel', avatarEmoji: '🌿', avatarBg: 'bg-emerald-100' },
    ],
    participantsCount: 5,
    maxParticipants: 8,
    isLive: true,
  },
  {
    id: 'room-2',
    name: 'Java Spring Boot & REST APIs Pod',
    subject: 'Java',
    code: 'LOOP-JAVA8',
    time: 'Live Now · 25m left',
    duration: '60 mins sprint',
    topic: 'JWT Auth, Hibernate ORM & Service Layer',
    tutor: {
      name: 'Rohit Deshmukh',
      role: 'Backend SDE Intern & 4th Year',
      avatarEmoji: '☕',
      rating: 4.85,
    },
    mutualBuddies: [
      { name: 'Neha Gupta', avatarEmoji: '👩‍🏫', avatarBg: 'bg-amber-100' },
    ],
    participantsCount: 4,
    maxParticipants: 6,
    isLive: true,
  },
  {
    id: 'room-3',
    name: 'Operating Systems: Concurrency & Semaphores',
    subject: 'OS',
    code: 'LOOP-OS12',
    time: 'Starts 11:30 AM · In 20 mins',
    duration: '30 mins sprint',
    topic: 'Deadlock Avoidance, Dining Philosophers & Mutex Locks',
    mutualBuddies: [
      { name: 'Riya Sharma', avatarEmoji: '🌸', avatarBg: 'bg-rose-100' },
      { name: 'Kabir Mehta', avatarEmoji: '⚡', avatarBg: 'bg-purple-100' },
    ],
    participantsCount: 3,
    maxParticipants: 6,
    isLive: false,
  },
  {
    id: 'room-4',
    name: 'Flutter & Mobile UI Claymorphism Sprint',
    subject: 'Flutter',
    code: 'LOOP-FLUT7',
    time: 'Starts 2:00 PM · Today',
    duration: '45 mins sprint',
    topic: 'Custom Animators, State Management & Riverpod',
    tutor: {
      name: 'Simran Kaur',
      role: 'Mobile Lead (Google DSC DTU)',
      avatarEmoji: '📱',
      rating: 4.9,
    },
    mutualBuddies: [
      { name: 'Aarav Patel', avatarEmoji: '🌿', avatarBg: 'bg-emerald-100' },
    ],
    participantsCount: 6,
    maxParticipants: 10,
    isLive: false,
  },
  {
    id: 'room-5',
    name: 'DBMS SQL Query Optimization & Indexing',
    subject: 'DBMS',
    code: 'LOOP-DBMS3',
    time: 'Live Now',
    duration: '30 mins sprint',
    topic: 'B-Trees vs Hash Indexes & Execution Plan Analysis',
    mutualBuddies: [
      { name: 'Kabir Mehta', avatarEmoji: '⚡', avatarBg: 'bg-purple-100' },
    ],
    participantsCount: 2,
    maxParticipants: 6,
    isLive: true,
  },
];

function CampusLoop3DLogo({
  size = 'normal',
  onHighFive,
  colorTheme = 'dark',
  showControls = false,
  onColorThemeChange,
}: {
  size?: 'normal' | 'compact';
  onHighFive?: () => void;
  colorTheme?: 'dark' | 'indigo' | 'teal' | 'coral';
  showControls?: boolean;
  onColorThemeChange?: (theme: 'dark' | 'indigo' | 'teal' | 'coral') => void;
}) {
  const [internalColorTheme, setInternalColorTheme] = useState<'dark' | 'indigo' | 'teal' | 'coral'>('dark');
  const activeColorTheme = colorTheme || internalColorTheme;

  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [isTapped, setIsTapped] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [isHovered, setIsHovered] = useState(false);
  const angleRef = useRef(0);
  const [orbPositions, setOrbPositions] = useState({
    x1: 178,
    y1: 85,
    x2: 42,
    y2: 85,
  });

  // Mathematically exact Bernoulli Lemniscate infinity path
  const loopPathD = useMemo(() => {
    const cx = 110;
    const cy = 85;
    const A = 68;
    const B = 46;
    const steps = 140;
    let d = '';
    for (let i = 0; i <= steps; i++) {
      const theta = (i / steps) * 2 * Math.PI;
      const denom = 1 + Math.sin(theta) * Math.sin(theta);
      const x = cx + (A * Math.cos(theta)) / denom;
      const y = cy + (B * Math.sin(theta) * Math.cos(theta)) / denom;
      if (i === 0) d += `M ${x.toFixed(2)} ${y.toFixed(2)}`;
      else d += ` L ${x.toFixed(2)} ${y.toFixed(2)}`;
    }
    return d + ' Z';
  }, []);

  // Animate circulating orbs (coral & mint) along track
  useEffect(() => {
    let animId: number;
    let lastTime = performance.now();

    const animate = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      angleRef.current = (angleRef.current + delta * 2.4 * speedMultiplier) % (2 * Math.PI);

      const cx = 110;
      const cy = 85;
      const A = 68;
      const B = 46;

      const t1 = angleRef.current;
      const d1 = 1 + Math.sin(t1) * Math.sin(t1);
      const x1 = cx + (A * Math.cos(t1)) / d1;
      const y1 = cy + (B * Math.sin(t1) * Math.cos(t1)) / d1;

      const t2 = (angleRef.current + Math.PI) % (2 * Math.PI);
      const d2 = 1 + Math.sin(t2) * Math.sin(t2);
      const x2 = cx + (A * Math.cos(t2)) / d2;
      const y2 = cy + (B * Math.sin(t2) * Math.cos(t2)) / d2;

      setOrbPositions({ x1, y1, x2, y2 });
      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, [speedMultiplier]);

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    const tiltX = (y / (rect.height / 2)) * -22;
    const tiltY = (x / (rect.width / 2)) * 22;
    setTilt({ x: tiltX, y: tiltY });
    setSpeedMultiplier(2.2);
    setIsHovered(true);
  };

  const handlePointerLeave = () => {
    setTilt({ x: 0, y: 0 });
    setSpeedMultiplier(1);
    setIsHovered(false);
  };

  const handleTap = () => {
    setIsTapped(true);
    setTimeout(() => setIsTapped(false), 850);
    onHighFive?.();
  };

  const themeStyles = {
    dark: 'from-[#141522] via-[#0E0F17] to-[#08080C] border-white/20 shadow-[0_25px_60px_rgba(0,0,0,0.85)]',
    indigo: 'from-[#1C1744] via-[#120F2D] to-[#0A071E] border-indigo-400/30 shadow-[0_25px_60px_rgba(20,12,50,0.9)]',
    teal: 'from-[#0B2A2F] via-[#061C20] to-[#030F11] border-teal-400/30 shadow-[0_25px_60px_rgba(4,25,30,0.9)]',
    coral: 'from-[#331320] via-[#220B15] to-[#12050A] border-rose-400/30 shadow-[0_25px_60px_rgba(45,10,25,0.9)]',
  };

  const isCompact = size === 'compact';
  const cardWidth = isCompact ? 'w-16 h-16 rounded-2xl' : 'w-56 h-56 rounded-[44px]';

  return (
    <div className="flex flex-col items-center select-none">
      {/* 3D Perspective Container */}
      <div
        style={{ perspective: 1000 }}
        className="flex items-center justify-center cursor-pointer"
        onPointerMove={!isCompact ? handlePointerMove : undefined}
        onPointerLeave={!isCompact ? handlePointerLeave : undefined}
        onClick={handleTap}
        title="Tap for a high-five!"
      >
        <div
          style={{
            transform: isTapped
              ? undefined
              : `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) translateZ(${isHovered ? '25px' : '0px'})`,
            transition: isHovered ? 'transform 0.08s ease-out' : 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
          className={`relative ${cardWidth} p-2 bg-gradient-to-br ${themeStyles[activeColorTheme]} border-2 backdrop-blur-xl flex items-center justify-center overflow-hidden transition-shadow ${
            isTapped ? 'animate-tap-spin' : ''
          }`}
        >
          {/* Glass Specular Sheen (matching the video's gloss reflection) */}
          <div className="absolute -top-12 -right-12 w-36 h-36 bg-gradient-to-br from-white/30 via-white/10 to-transparent rounded-full blur-md pointer-events-none" />
          <div className="absolute inset-0 bg-radial at-top-left from-white/15 via-transparent to-black/40 pointer-events-none" />

          {/* Infinity Loop SVG Track & Circulating Orbs */}
          <svg
            viewBox="20 20 180 130"
            className="w-full h-full relative z-10 filter drop-shadow-[0_8px_16px_rgba(0,0,0,0.7)]"
          >
            {/* Ambient Track Glow */}
            <path
              d={loopPathD}
              fill="none"
              stroke="rgba(255,255,255,0.18)"
              strokeWidth="28"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="filter blur-[3px]"
            />

            {/* Pristine White Solid 3D Ribbon Track */}
            <path
              d={loopPathD}
              fill="none"
              stroke="#FFFFFF"
              strokeWidth="18"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Inner Ribbon Depth Highlight */}
            <path
              d={loopPathD}
              fill="none"
              stroke="rgba(240, 240, 255, 0.95)"
              strokeWidth="14"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Orb 1: Coral / Peach-Orange Glowing Sphere */}
            <g transform={`translate(${orbPositions.x1}, ${orbPositions.y1})`}>
              <circle r="14" fill="#FF5E62" opacity="0.4" className="filter blur-[2px]" />
              <circle r="8.5" fill="#FF5E62" />
              <circle cx="-2.5" cy="-2.5" r="3" fill="#FFA5A7" opacity="0.9" />
            </g>

            {/* Orb 2: Mint / Seafoam-Teal Glowing Sphere */}
            <g transform={`translate(${orbPositions.x2}, ${orbPositions.y2})`}>
              <circle r="14" fill="#20E3B2" opacity="0.4" className="filter blur-[2px]" />
              <circle r="8.5" fill="#20E3B2" />
              <circle cx="-2.5" cy="-2.5" r="3" fill="#A8F8E4" opacity="0.9" />
            </g>
          </svg>
        </div>
      </div>

      {showControls && !isCompact && (
        <div className="flex flex-col items-center mt-3 space-y-2">
          {/* Hint text from video */}
          <p className="text-[11px] font-semibold text-[#DFB6B2]/80 tracking-wide m-0">
            Move to tilt and speed up • tap for a high-five
          </p>

          {/* Theme Colours Row (matching video) */}
          <div className="flex items-center gap-2 pt-0.5">
            <span className="text-[10px] font-bold text-[#DFB6B2]/60 uppercase tracking-wider mr-1">
              Colours
            </span>
            {[
              { id: 'indigo', bg: 'bg-[#2B2358]' },
              { id: 'teal', bg: 'bg-[#10434A]' },
              { id: 'coral', bg: 'bg-[#521E2C]' },
              { id: 'dark', bg: 'bg-[#181924]' },
            ].map((col) => (
              <button
                key={col.id}
                onClick={() => {
                  setInternalColorTheme(col.id as any);
                  onColorThemeChange?.(col.id as any);
                }}
                className={`w-6 h-6 rounded-full ${col.bg} transition-all cursor-pointer ${
                  activeColorTheme === col.id ? 'ring-2 ring-white scale-110 shadow-sm' : 'opacity-70 hover:opacity-100'
                }`}
                title={`Switch to ${col.id} theme`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [hub, setHub] = useState<MainHub>('study');
  const [studySubView, setStudySubView] = useState<StudySubView>('streak_timer');
  const [notesSubView, setNotesSubView] = useState<NotesSubView>('marketplace');
  const [tutorsSubView, setTutorsSubView] = useState<TutorsSubView>('browse');
  const [communitySubView, setCommunitySubView] = useState<CommunitySubView>('doubts');
  const [isVouchersExpanded, setIsVouchersExpanded] = useState(false);

  // Theme state: 'warm' (default) vs 'dark' (high-contrast dark mode)
  const [appTheme, setAppTheme] = useState<'warm' | 'dark'>(() => {
    return (localStorage.getItem('campusloop_app_theme') as 'warm' | 'dark') || 'warm';
  });

  // 3D Logo color theme on the welcome page
  const [welcomeLogoTheme, setWelcomeLogoTheme] = useState<'dark' | 'indigo' | 'teal' | 'coral'>('dark');

  useEffect(() => {
    try {
      localStorage.setItem('campusloop_app_theme', appTheme);
      if (appTheme === 'dark') {
        document.documentElement.classList.add('dark-theme');
        document.body.classList.add('dark-theme');
      } else {
        document.documentElement.classList.remove('dark-theme');
        document.body.classList.remove('dark-theme');
      }
    } catch {
      // Ignore storage errors in restricted contexts
    }
  }, [appTheme]);

  // Authentication State & Front Page Welcome Modal (Opens directly on app launch)
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [authEmailInput, setAuthEmailInput] = useState('');
  const [authNameInput, setAuthNameInput] = useState('');

  // Instagram-style Buddy Discovery & Direct Message Modals
  const [showActivityModal, setShowActivityModal] = useState(false);
  const [showDirectMessagesModal, setShowDirectMessagesModal] = useState(false);
  const [activeDmPeer, setActiveDmPeer] = useState<Peer | null>(null);
  const [dmInputText, setDmInputText] = useState('');
  const [dmThreads, setDmThreads] = useState<Record<string, { sender: string; text: string; time: string }[]>>({
    p1: [
      { sender: 'Riya Sharma', text: 'Hey Rahul! Did you solve problem 3 on Trees?', time: '10:14 AM' },
      { sender: 'You', text: 'Working on BFS traversal right now in the library!', time: '10:18 AM' },
      { sender: 'Riya Sharma', text: 'Awesome, let me know if you want to hop on the whiteboard pod!', time: '10:20 AM' },
    ],
    p2: [
      { sender: 'Aarav Patel', text: 'Sent you the Flutter Riverpod repo for the campus project!', time: 'Yesterday' },
      { sender: 'You', text: 'Thanks Aarav, checking it out tonight.', time: 'Yesterday' },
    ],
    p4: [
      { sender: 'Kabir Verma', text: 'OS review session tomorrow at 4 PM if you want to join!', time: '2 days ago' },
    ],
  });

  // User Profile Customization State (Instagram-Style Cartoon Avatar & Bio)
  const [userProfile, setUserProfile] = useState({
    name: 'Rahul Sharma',
    username: '@rahul.dev',
    college: 'Delhi Technological University (DTU)',
    year: '3rd Year · Computer Science & Eng.',
    rollNo: '2K23/CO/312',
    bio: 'DTU CSE \'27 | 480+ LeetCode Solved | Smart India Hackathon \'26 Finalist | 5 Vouchers Unlocked | Grinding Trees, DP & System Design for SDE-1 Internships 🚀',
    avatar: '/assets/aistudio/image_bfa36e2d.png',
    leetcodeSolved: 480,
    leetcodeEasy: 180,
    leetcodeMed: 240,
    leetcodeHard: 60,
    contestRating: 1856,
    globalRank: 'Top 4.2%',
    hackathons: [
      { name: 'Smart India Hackathon 2026', title: 'EduSphere: Adaptive AI Tutor', role: 'Team Lead', badge: 'National Finalist 🏆' },
      { name: 'TCS-iON Ninja Challenge', title: 'CloudVault: Secure FinTech', role: 'Backend & ML', badge: 'Top 10 Finalist ⚡' },
      { name: 'Flipkart GRiD 7.0', title: 'Warehouse AMR Path Optimization', role: 'Algorithm Dev', badge: 'Round 2 Qualified 🚀' },
    ],
  });

  // Settings & Edit Profile Modals
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showRemoveBuddyModal, setShowRemoveBuddyModal] = useState(false);

  // Edit Profile Form State
  const [editName, setEditName] = useState(userProfile.name);
  const [editBio, setEditBio] = useState(userProfile.bio);
  const [editAvatar, setEditAvatar] = useState(userProfile.avatar);
  const [editLeetCode, setEditLeetCode] = useState(userProfile.leetcodeSolved);

  // Instagram-style Buddy Discovery State
  const [peersList, setPeersList] = useState<Peer[]>(PEERS);
  const [activeStoryPeer, setActiveStoryPeer] = useState<Peer | null>(null);
  const [buddyViewMode, setBuddyViewMode] = useState<'feed' | 'match'>('feed');

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // 1. Study Matcher & Room
  const [mood, setMood] = useState<MoodType>('together');
  const [slot, setSlot] = useState<SlotType>(30);
  const [subj, setSubj] = useState<SubjectType>('DSA');
  const [matches, setMatches] = useState<Peer[] | null>(null);
  const [activeRoom, setActiveRoom] = useState<{
    name: string;
    subject: SubjectType;
    timer: number;
    isRunning: boolean;
    mode: 'study' | 'break';
  } | null>(null);

  // Shared Whiteboard Canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [drawColor, setDrawColor] = useState('#2B124C');
  const [chatMessages, setChatMessages] = useState<{ sender: string; text: string; time: string }[]>([
    { sender: 'Riya', text: 'Hey Rahul! Let’s solve question 3 on Trees.', time: '10:02 AM' },
    { sender: 'Aarav', text: 'Whiteboard is open for diagrams!', time: '10:04 AM' },
  ]);
  const [chatInput, setChatInput] = useState('');

  // 2. AI Doubt Solver State
  const [aiDoubtInput, setAiDoubtInput] = useState('');
  const [aiDoubtSubject, setAiDoubtSubject] = useState<SubjectType>('DSA');
  const [aiSolving, setAiSolving] = useState(false);
  const [aiSolution, setAiSolution] = useState<{
    concept: string;
    steps: string[];
    code: string;
    complexity: string;
    recommendedPeer: { name: string; year: string; bio: string; solvedPostId: string };
  } | null>(null);

  // 3. Smart Study Planner State
  const [examDaysLeft, setExamDaysLeft] = useState(14);
  const [dailyHours, setDailyHours] = useState(3);
  const [plannerSubjects, setPlannerSubjects] = useState<SubjectType[]>(['DSA', 'Java', 'OS']);
  const [generatedPlan, setGeneratedPlan] = useState<PlannedDay[]>([
    { day: 'Day 1 (Mon)', subject: 'DSA', topic: 'Binary Search & Two Pointers (15 LeetCode)', duration: '3 hrs', completed: true, type: 'problems' },
    { day: 'Day 2 (Tue)', subject: 'Java', topic: 'OOP Invariants & Collections Framework', duration: '3 hrs', completed: true, type: 'concept' },
    { day: 'Day 3 (Wed)', subject: 'OS', topic: 'CPU Scheduling & Banker’s Deadlock Algorithm', duration: '3 hrs', completed: false, type: 'concept' },
    { day: 'Day 4 (Thu)', subject: 'DSA', topic: 'Trees & BFS/DFS Level Order Traversal', duration: '3 hrs', completed: false, type: 'problems' },
    { day: 'Day 5 (Fri)', subject: 'Java', topic: 'Spring Boot JPA & N+1 Query Optimization', duration: '3 hrs', completed: false, type: 'problems' },
    { day: 'Day 6 (Sat)', subject: 'OS', topic: 'Virtual Memory & Page Replacement Simulations', duration: '3 hrs', completed: false, type: 'problems' },
    { day: 'Day 7 (Sun)', subject: 'DSA', topic: 'Weekly Revision Marathon & Mock Quiz Battle', duration: '3 hrs', completed: false, type: 'revision' },
  ]);

  // 4. Notes Marketplace & Summarizer State
  const [selectedNote, setSelectedNote] = useState<NoteItem>(NOTES_LIBRARY[0]);
  const [activeFlashcardIdx, setActiveFlashcardIdx] = useState(0);
  const [flashcardFlipped, setFlashcardFlipped] = useState(false);

  // 5. Peer Tutoring State
  const [selectedTutor, setSelectedTutor] = useState<Tutor | null>(null);
  const [bookingSlot, setBookingSlot] = useState<string>('');
  const [userPoints, setUserPoints] = useState(380);
  const [bookedSessions, setBookedSessions] = useState<{ tutor: string; subject: string; time: string }[]>([]);

  // Community State
  const [posts, setPosts] = useState<CommunityPost[]>(INITIAL_COMMUNITY);
  const [newDoubtText, setNewDoubtText] = useState('');
  const [events, setEvents] = useState<CampusEvent[]>(INITIAL_EVENTS);
  const [teams, setTeams] = useState<ProjectTeam[]>(INITIAL_TEAMS);

  // 6. Study Streak Timer & Rewards State
  const [streak, setStreak] = useState(5);
  const [longestStreak, setLongestStreak] = useState(14);
  const [streakSparks, setStreakSparks] = useState(320);
  const [todayFocusMinutes, setTodayFocusMinutes] = useState(45);
  const [todayStreakCompleted, setTodayStreakCompleted] = useState(false);
  const [streakTimerDuration, setStreakTimerDuration] = useState(25 * 60);
  const [streakTimeRemaining, setStreakTimeRemaining] = useState(25 * 60);
  const [isStreakTimerRunning, setIsStreakTimerRunning] = useState(false);
  const [streakSubject, setStreakSubject] = useState<SubjectType>('DSA');
  const [streakAmbientSound, setStreakAmbientSound] = useState<'lofi' | 'library' | 'rain' | 'off'>('lofi');
  const [streakDayLog, setStreakDayLog] = useState([
    { day: 'Mon', date: 'Oct 23', minutes: 50, completed: true },
    { day: 'Tue', date: 'Oct 24', minutes: 40, completed: true },
    { day: 'Wed', date: 'Oct 25', minutes: 60, completed: true },
    { day: 'Thu', date: 'Oct 26', minutes: 30, completed: true },
    { day: 'Fri', date: 'Today', minutes: 45, completed: false, isToday: true },
    { day: 'Sat', date: 'Tomorrow', minutes: 0, completed: false },
    { day: 'Sun', date: 'Oct 29', minutes: 0, completed: false },
  ]);
  const [vouchers, setVouchers] = useState<StudyVoucher[]>(INITIAL_VOUCHERS);
  const [voucherFilter, setVoucherFilter] = useState<'all' | 'food' | 'books' | 'tech' | 'stationery'>('all');
  const [claimedVouchers, setClaimedVouchers] = useState<{ id: string; voucher: StudyVoucher; claimedAt: string }[]>([
    {
      id: 'claim-init-1',
      voucher: INITIAL_VOUCHERS[0],
      claimedAt: 'Yesterday',
    },
  ]);
  const [showVouchersModal, setShowVouchersModal] = useState(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const showToast = (msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => setToastMessage(null), 3200);
  };

  // Study Streak Timer Countdown Effect
  useEffect(() => {
    if (!isStreakTimerRunning) return;
    const interval = setInterval(() => {
      setStreakTimeRemaining((prev) => {
        if (prev <= 1) {
          setIsStreakTimerRunning(false);
          const minsAdded = Math.round(streakTimerDuration / 60);
          setTodayFocusMinutes((m) => m + minsAdded);
          setStreakSparks((s) => s + 50);
          setUserPoints((p) => p + 40);
          setTodayStreakCompleted(true);
          setStreakDayLog((days) =>
            days.map((d) => (d.isToday ? { ...d, completed: true, minutes: d.minutes + minsAdded } : d))
          );
          setStreak((cur) => cur + 1);
          showToast(`🔥 Daily Study Goal Achieved! +50 Sparks & +40 Pts earned! Streak is now ${streak + 1} days! 🎉`);
          return streakTimerDuration;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isStreakTimerRunning, streakTimerDuration, streak]);

  const handleClaimStreakManual = () => {
    const elapsedMins = Math.max(15, Math.round((streakTimerDuration - streakTimeRemaining) / 60) || 25);
    setIsStreakTimerRunning(false);
    setStreakTimeRemaining(streakTimerDuration);
    setTodayFocusMinutes((m) => m + elapsedMins);
    setStreakSparks((s) => s + 50);
    setUserPoints((p) => p + 40);
    setTodayStreakCompleted(true);
    setStreakDayLog((days) =>
      days.map((d) => (d.isToday ? { ...d, completed: true, minutes: d.minutes + elapsedMins } : d))
    );
    if (!todayStreakCompleted) {
      setStreak((cur) => cur + 1);
      showToast(`🔥 Streak Saved for Today! +50 Sparks added! New Streak: ${streak + 1} Days! 🥳`);
    } else {
      showToast(`🔥 Extra study session logged! +50 Sparks added to wallet! 🌟`);
    }
  };

  const handleRedeemVoucher = (voucher: StudyVoucher) => {
    if (streakSparks < voucher.sparksCost) {
      showToast(`Need ${voucher.sparksCost - streakSparks} more Sparks! Complete a study session to unlock! ⏱️`);
      return;
    }
    setStreakSparks((s) => s - voucher.sparksCost);
    setVouchers((prev) =>
      prev.map((v) => (v.id === voucher.id ? { ...v, claimed: true } : v))
    );
    setClaimedVouchers((prev) => [
      ...prev,
      {
        id: `claim-${Date.now()}`,
        voucher,
        claimedAt: 'Just now',
      },
    ]);
    showToast(`🎉 Voucher Unlocked: ${voucher.title}! Code: ${voucher.promoCode}`);
  };

  const copyVoucherCode = (code: string) => {
    navigator.clipboard?.writeText?.(code);
    setCopiedCode(code);
    showToast(`Coupon code "${code}" copied! Show this at campus counter! 📋`);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  // Canvas Drawing Handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    ctx.strokeStyle = drawColor;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    showToast('Whiteboard cleared!');
  };

  // Pomodoro Room Timer
  useEffect(() => {
    if (!activeRoom || !activeRoom.isRunning) return;
    const timer = setInterval(() => {
      setActiveRoom((prev) => {
        if (!prev) return null;
        if (prev.timer <= 1) {
          const nextMode = prev.mode === 'study' ? 'break' : 'study';
          showToast(nextMode === 'break' ? 'Time for 5 min Pomodoro break! ☕' : 'Break over! Focus mode ON! 🧠');
          return {
            ...prev,
            mode: nextMode,
            timer: nextMode === 'break' ? 5 * 60 : 25 * 60,
          };
        }
        return { ...prev, timer: prev.timer - 1 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [activeRoom]);

  // AI Doubt Solver Execution
  const handleSolveWithAI = () => {
    if (!aiDoubtInput.trim()) {
      showToast('Please enter your code or doubt question!');
      return;
    }
    setAiSolving(true);
    setTimeout(() => {
      setAiSolving(false);
      setAiSolution({
        concept: `Step-by-step resolution for ${aiDoubtSubject}: Concept Analysis`,
        steps: [
          '1. Root Cause: In this problem pattern, state transitions must maintain tree balancing invariants or loop invariants.',
          '2. Algorithmic Fix: Apply a two-pointer technique or rotation pivot to eliminate redundant comparisons.',
          '3. Boundary Conditions: Verify empty node or base condition (n <= 1) before triggering recursion.',
        ],
        code: `// Optimized Solution for ${aiDoubtSubject}\nfunction solve(root, target) {\n  if (!root) return null;\n  // Fast path lookup\n  if (root.val === target) return root;\n  return root.val > target ? solve(root.left, target) : solve(root.right, target);\n}`,
        complexity: 'Time Complexity: O(log n) average · Space Complexity: O(1) auxiliary',
        recommendedPeer: {
          name: 'Riya Sharma',
          year: '3rd Year CSE (98% Rating)',
          bio: 'Solved 12 similar questions on this exact topic in #DSA Community.',
          solvedPostId: 'c1',
        },
      });
      showToast('AI step-by-step breakdown & peer match generated! 🤖✨');
    }, 1100);
  };

  // Generate Smart Study Plan
  const handleGeneratePlan = () => {
    showToast('Generating personalized weekly study timetable... 📅');
    setTimeout(() => {
      const newPlan: PlannedDay[] = [
        { day: 'Day 1 (Mon)', subject: plannerSubjects[0] || 'DSA', topic: 'Core Concept Revision & Top 10 Problems', duration: `${dailyHours} hrs`, completed: false, type: 'concept' },
        { day: 'Day 2 (Tue)', subject: plannerSubjects[1] || 'Java', topic: 'Implementation & Debugging Practice', duration: `${dailyHours} hrs`, completed: false, type: 'problems' },
        { day: 'Day 3 (Wed)', subject: plannerSubjects[2] || 'OS', topic: 'Previous Year Question Solving & Notes', duration: `${dailyHours} hrs`, completed: false, type: 'problems' },
        { day: 'Day 4 (Thu)', subject: plannerSubjects[0] || 'DSA', topic: 'Hard Pattern Drills & Peer Code Review', duration: `${dailyHours} hrs`, completed: false, type: 'problems' },
        { day: 'Day 5 (Fri)', subject: plannerSubjects[1] || 'Java', topic: 'Full Chapter Synthesis & Flashcards Review', duration: `${dailyHours} hrs`, completed: false, type: 'revision' },
        { day: 'Day 6 (Sat)', subject: plannerSubjects[2] || 'OS', topic: 'Formula & Invariant Memorization', duration: `${dailyHours} hrs`, completed: false, type: 'concept' },
        { day: 'Day 7 (Sun)', subject: plannerSubjects[0] || 'DSA', topic: 'Mock Battle Quiz & Weakness Analysis', duration: `${dailyHours} hrs`, completed: false, type: 'revision' },
      ];
      setGeneratedPlan(newPlan);
      showToast('New study schedule ready! Stick to your daily goals! 🎯');
    }, 800);
  };

  // Book Tutoring Session
  const handleConfirmBooking = () => {
    if (!selectedTutor || !bookingSlot) {
      showToast('Please select a preferred slot!');
      return;
    }
    if (userPoints < selectedTutor.hourlyPoints) {
      showToast('Insufficient campus points! Solve community doubts to earn points.');
      return;
    }
    setUserPoints((prev) => prev - selectedTutor.hourlyPoints);
    setBookedSessions([
      ...bookedSessions,
      { tutor: selectedTutor.name, subject: selectedTutor.specialty[0], time: bookingSlot },
    ]);
    showToast(`1-on-1 Session booked with ${selectedTutor.name}! Calendar invite sent! 🎓`);
    setSelectedTutor(null);
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // -------------------------------------------------------------
  // FRONT PAGE / WELCOME & LOGIN SCREEN (When not logged in)
  // -------------------------------------------------------------
  if (!isLoggedIn) {
    return (
      <div
        className="w-full min-h-screen text-[#FBE4D8] flex flex-col justify-between max-w-[440px] mx-auto shadow-2xl relative select-none antialiased px-5 py-6 overflow-y-auto bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(to bottom, rgba(10, 12, 24, 0.22) 0%, rgba(10, 12, 24, 0.42) 50%, rgba(8, 10, 20, 0.88) 100%), url(${campusSunsetBg})`,
          backgroundColor: '#070B19',
        }}
      >
        {/* HERO SECTION: ONLY 3D INFINITY LOGO (Spinning & Zooming Forward) */}
        <div className="relative z-10 text-center my-auto py-2 space-y-4">
          {/* Logo with 3D Spinning & Zooming Entrance ('gol ghumta hua aye age ki taraf') */}
          <div className="animate-spin-zoom-in my-1 flex justify-center">
            <CampusLoop3DLogo
              colorTheme={welcomeLogoTheme}
              showControls={false}
              onHighFive={() => showToast('✋ High-Five! You powered up the study loop! 🚀')}
            />
          </div>

          {/* CampusLoop with Campus in white and Loop in bright electric cyan */}
          <div className="space-y-1.5 pt-1">
            <h1 className="text-4xl sm:text-5xl font-black tracking-tight leading-none drop-shadow-xl font-sans">
              <span className="text-white">Campus</span>
              <span className="text-[#00C2FF]">Loop</span>
            </h1>
            <p
              style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
              className="text-base sm:text-lg text-[#FBE4D8] font-normal italic max-w-[340px] mx-auto leading-relaxed pt-1 drop-shadow-sm"
            >
              Your All-in-One Campus Academic & Peer Learning Platform
            </p>
          </div>

          {/* SIGN UP & GOOGLE LOGIN CARD (Larger fonts, Times Roman styling, beautiful spacious padding) */}
          <div className="clay-card-warm p-6 sm:p-8 border-2 border-[#DFB6B2] space-y-5 text-[#190019] text-left relative z-10 shadow-2xl mt-4 rounded-[32px]">
            <div className="text-center space-y-1.5">
              <span
                style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
                className="inline-block px-4 py-1.5 rounded-full bg-[#854F6C]/15 text-[#854F6C] text-sm sm:text-base font-bold tracking-wide"
              >
                🎓 Campus Student Sign In
              </span>

              {/* Welcome!! in pure black with Times New Roman italic & upward-extending right side of W */}
              <h2
                style={{ fontFamily: '"Times New Roman", Times, "Playfair Display", Georgia, serif' }}
                className="text-4xl sm:text-5xl italic font-bold text-black tracking-wider text-center m-0 py-1 select-none drop-shadow-xs"
              >
                <span className="inline-flex items-baseline">
                  <span className="relative inline-block">
                    W
                    {/* Delicate upward flourish ensuring the right side of W reaches elegantly up */}
                    <svg
                      className="absolute -top-2 -right-0.5 w-4 h-4 text-black pointer-events-none overflow-visible"
                      viewBox="0 0 12 12"
                      fill="none"
                    >
                      <path
                        d="M 1 10 C 2 6, 4 2.5, 9 1 C 8 2.5, 8 4, 9 5"
                        stroke="#000000"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                      />
                    </svg>
                  </span>
                  <span>elcome!!</span>
                </span>
              </h2>
            </div>

            {/* 1. Continue with Google Button */}
            <button
              onClick={() => {
                setIsLoggedIn(true);
                showToast('🎉 Welcome to CampusLoop, Rahul! 5-Day Study Streak Active!');
              }}
              style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
              className="w-full py-4 px-5 rounded-2xl bg-white hover:bg-slate-50 border-2 border-slate-200 text-[#190019] font-bold text-base sm:text-lg shadow-md active:scale-98 transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              {/* Google 4-Color 'G' Logo SVG */}
              <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3 my-1">
              <div className="flex-1 h-px bg-[#DFB6B2]/80" />
              <span
                style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
                className="text-sm sm:text-base font-bold text-[#854F6C] italic tracking-wide"
              >
                or College ID
              </span>
              <div className="flex-1 h-px bg-[#DFB6B2]/80" />
            </div>

            {/* College Roll No / Email Input */}
            <div className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  defaultValue="2K23/CO/312 (DTU)"
                  placeholder="Enter Roll No or College Email"
                  style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
                  className="w-full text-base sm:text-lg font-bold text-[#2B124C] bg-white border-2 border-[#DFB6B2] rounded-2xl px-4 py-4 focus:outline-none focus:ring-2 focus:ring-[#854F6C] shadow-inner"
                />
                <span className="absolute right-4 top-4 text-lg">🎓</span>
              </div>

              {/* Direct Demo Login Button */}
              <button
                onClick={() => {
                  setIsLoggedIn(true);
                  showToast('🎉 Welcome to CampusLoop, Rahul! 5-Day Study Streak Active!');
                }}
                style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
                className="w-full py-4 px-5 rounded-2xl font-bold text-base sm:text-lg text-white bg-gradient-to-r from-[#854F6C] via-[#522B5B] to-[#2B124C] border-2 border-[#522B5B] shadow-lg active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer hover:brightness-110"
              >
                <span>Enter Campus as Rahul Sharma →</span>
              </button>
            </div>
          </div>
        </div>

        {/* BOTTOM SECTION: Move to tilt & Colours palette relocated to the very bottom */}
        <div className="relative z-10 flex flex-col items-center mt-6 pt-3 pb-2 border-t border-white/10 space-y-2.5">
          {/* Move to tilt and speed up hint */}
          <p
            style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
            className="text-sm sm:text-base font-normal italic text-[#FBE4D8] tracking-wide m-0 flex items-center gap-2 drop-shadow-sm"
          >
            <span>Move to tilt and speed up</span>
            <span className="text-white/50">•</span>
            <span>tap for a high-five ✋</span>
          </p>

          {/* Colours Selector Row */}
          <div className="flex items-center gap-3 pt-0.5">
            <span
              style={{ fontFamily: '"Times New Roman", Times, Georgia, serif' }}
              className="text-xs sm:text-sm font-bold text-[#FBE4D8]/90 tracking-widest mr-0.5 uppercase"
            >
              COLOURS
            </span>
            {[
              { id: 'indigo', bg: 'bg-[#2B2358]', label: 'Indigo' },
              { id: 'teal', bg: 'bg-[#10434A]', label: 'Teal' },
              { id: 'coral', bg: 'bg-[#521E2C]', label: 'Coral' },
              { id: 'dark', bg: 'bg-[#181924]', label: 'Dark' },
            ].map((col) => (
              <button
                key={col.id}
                onClick={() => setWelcomeLogoTheme(col.id as any)}
                className={`w-7 h-7 rounded-full ${col.bg} transition-all cursor-pointer ${
                  welcomeLogoTheme === col.id
                    ? 'ring-3 ring-white ring-offset-2 ring-offset-[#0C0A1A] scale-110 shadow-lg'
                    : 'opacity-70 hover:opacity-100 hover:scale-105'
                }`}
                title={`Switch logo to ${col.label} theme`}
              />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`w-full min-h-screen clay-bg-canvas text-[#190019] flex flex-col justify-between max-w-[440px] mx-auto shadow-2xl relative select-none antialiased ${appTheme === 'dark' ? 'dark-theme' : ''}`}>
      {/* Instagram-Style Clean Top Header */}
      <header className="px-4 py-2.5 flex items-center justify-between shrink-0 sticky top-0 z-40 bg-[#FBE4D8]/95 backdrop-blur-md border-b border-[#DFB6B2]/40">
        <div
          onClick={() => {
            setHub('study');
            setStudySubView('matcher');
            setBuddyViewMode('feed');
          }}
          className="flex items-center gap-1 cursor-pointer select-none group"
        >
          <h1 className="text-2xl font-black tracking-tight font-sans drop-shadow-xs flex items-center">
            <span className={appTheme === 'dark' ? 'text-white' : 'text-[#2B124C]'}>Campus</span>
            <span className="text-[#00C2FF]">Loop</span>
          </h1>
          <ChevronRight className="w-4 h-4 text-[#854F6C] rotate-90 group-hover:text-[#2B124C] transition-colors" />
        </div>

        {/* Instagram-Style Right Action Icons: Heart (Activity) and Settings */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowActivityModal(true)}
            className="relative p-1.5 rounded-full hover:bg-white/60 active:scale-90 transition-all cursor-pointer text-[#2B124C]"
            title="Activity & Campus Notifications"
          >
            <Heart className="w-6 h-6 stroke-[2]" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-[#FBE4D8]" />
          </button>

          <button
            onClick={() => setShowSettingsModal(true)}
            className="relative p-1.5 rounded-full hover:bg-white/60 active:scale-90 transition-all cursor-pointer text-[#2B124C]"
            title="Settings (Edit Profile, Manage Buddies, Switch Account)"
          >
            <Settings className="w-6 h-6 stroke-[2]" />
          </button>
        </div>
      </header>

      {/* Screen Body Content */}
      <main className="flex-1 overflow-y-auto px-4 py-3 space-y-3.5">
        {/* ========================================================= */}
        {/* 1. HUB: STUDY (Streak Timer, Matcher, Room, AI, Planner) */}
        {/* ========================================================= */}
        {hub === 'study' && (
          <div className="space-y-3.5 animate-fadeIn">
            {/* Sub-navigation Pills */}
            <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'streak_timer', label: 'Streak & Vouchers', icon: '⏱️' },
                { id: 'matcher', label: 'Buddy Match', icon: '🧠' },
                { id: 'room', label: 'Group Room', icon: '🎧' },
                { id: 'ai_solver', label: 'AI Doubt Solver', icon: '🤖' },
                { id: 'planner', label: 'Smart Planner', icon: '📅' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setStudySubView(tab.id as StudySubView)}
                  className={`rounded-full px-3 py-1.5 text-xs font-black shrink-0 transition-all cursor-pointer flex items-center gap-1 ${
                    studySubView === tab.id ? 'clay-pill-btn-active' : 'clay-pill-btn'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* 1. STUDY STREAK TIMER & CAMPUS VOUCHERS */}
            {studySubView === 'streak_timer' && (
              <div className="space-y-3.5">
                {/* Daily Streak Hero Banner */}
                <div className="clay-card-warm p-4 border-2 border-[#DFB6B2] relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-400 via-orange-400 to-rose-400 p-0.5 shadow-md flex items-center justify-center shrink-0">
                        <div className="w-full h-full bg-white/90 rounded-[14px] flex flex-col items-center justify-center">
                          <Flame className="w-6 h-6 text-orange-500 fill-orange-500 animate-bounce" />
                          <span className="text-[10px] font-black text-[#2B124C] leading-none mt-0.5">{streak}d</span>
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-black uppercase text-[#854F6C] bg-white/80 px-2 py-0.5 rounded-full">
                            Daily Study Streak 🔥
                          </span>
                          <span className="text-[10px] font-bold text-amber-700 bg-amber-100/90 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            Freeze Active
                          </span>
                        </div>
                        <h2 className="text-[18px] font-black text-[#2B124C] mt-1 leading-tight flex items-center gap-1.5">
                          <span>{streak} Days Streak!</span>
                          <span className="text-xs font-bold text-[#854F6C]">(Best: {longestStreak}d)</span>
                        </h2>
                        <p className="text-[11px] font-bold text-[#854F6C] mt-0.5 leading-tight">
                          {todayStreakCompleted
                            ? '🎉 Today’s streak is locked! You studied 45+ mins.'
                            : '⚡ Study 15+ mins with the timer below to maintain your streak!'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Quick Sparks & Claimed Vouchers Drawer Button */}
                  <div className="mt-3 pt-2.5 border-t border-[#DFB6B2]/50 flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-black text-[#2B124C]">
                      <Sparkles className="w-4 h-4 text-amber-500 fill-amber-400" />
                      <span>{streakSparks} Streak Sparks Available</span>
                    </div>

                    <button
                      onClick={() => setShowVouchersModal(true)}
                      className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-xl flex items-center gap-1 cursor-pointer"
                    >
                      <Ticket className="w-3 h-3" />
                      <span>My Vouchers ({claimedVouchers.length})</span>
                    </button>
                  </div>
                </div>

                {/* 7-Day Weekly Streak Calendar */}
                <div className="clay-card p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#2B124C] flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#854F6C]" />
                      <span>Weekly Streak Board</span>
                    </span>
                    <span className="text-[10px] font-black text-[#854F6C]">
                      Today: <span className="text-[#2B124C]">{todayFocusMinutes} min studied</span>
                    </span>
                  </div>

                  <div className="grid grid-cols-7 gap-1.5">
                    {streakDayLog.map((item, idx) => {
                      const isCompleted = item.completed || (item.isToday && todayStreakCompleted);
                      return (
                        <div
                          key={idx}
                          className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all ${
                            item.isToday
                              ? 'bg-gradient-to-b from-[#DFB6B2]/60 to-[#FBE4D8] border-2 border-orange-400 shadow-sm scale-105'
                              : isCompleted
                              ? 'clay-inset-box bg-white/70'
                              : 'bg-white/40 border border-[#DFB6B2]/40 opacity-70'
                          }`}
                        >
                          <span className="text-[10px] font-bold text-[#854F6C]">{item.day}</span>
                          <div className="my-1">
                            {isCompleted ? (
                              <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-[10px] font-black shadow-sm">
                                <Check className="w-3.5 h-3.5" />
                              </div>
                            ) : item.isToday ? (
                              <div className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center text-[10px] font-black shadow-sm animate-pulse">
                                <Flame className="w-3.5 h-3.5 fill-white" />
                              </div>
                            ) : (
                              <div className="w-6 h-6 rounded-full border border-dashed border-[#DFB6B2] text-[#854F6C] flex items-center justify-center text-[9px] font-bold">
                                ·
                              </div>
                            )}
                          </div>
                          <span className="text-[9px] font-black text-[#2B124C]">
                            {item.minutes > 0 ? `${item.minutes}m` : '-'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Interactive Study Timer Card */}
                <div className="clay-card p-4 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xs font-black text-[#2B124C] flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-[#854F6C]" />
                        <span>Daily Focus Timer</span>
                      </h3>
                      <p className="text-[10px] text-[#854F6C] font-semibold mt-0.5">
                        Complete focus sessions to earn Streak Sparks & Campus Vouchers!
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="text-[10px] font-black text-orange-600 bg-orange-100 px-2 py-0.5 rounded-full">
                        +50 Sparks / 25m
                      </span>
                    </div>
                  </div>

                  {/* Subject Selector */}
                  <div>
                    <label className="text-[11px] font-black text-[#2B124C] block mb-1">Target Subject</label>
                    <div className="grid grid-cols-6 gap-1">
                      {SUBJECTS.map((s) => (
                        <button
                          key={s}
                          onClick={() => setStreakSubject(s)}
                          className={`py-1 text-[10px] font-black rounded-lg transition-all ${
                            streakSubject === s ? 'clay-pill-btn-active' : 'clay-pill-btn'
                          }`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Mode / Duration Presets */}
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { mins: 15, label: '15m Sprint', sparks: 25 },
                      { mins: 25, label: '25m Focus', sparks: 50 },
                      { mins: 45, label: '45m Deep', sparks: 80 },
                      { mins: 60, label: '60m Marathon', sparks: 100 },
                    ].map((mode) => {
                      const isSelected = streakTimerDuration === mode.mins * 60;
                      return (
                        <button
                          key={mode.mins}
                          onClick={() => {
                            setStreakTimerDuration(mode.mins * 60);
                            setStreakTimeRemaining(mode.mins * 60);
                            setIsStreakTimerRunning(false);
                          }}
                          className={`p-2 rounded-xl text-center transition-all ${
                            isSelected
                              ? 'bg-gradient-to-b from-[#522B5B] to-[#2B124C] text-[#FBE4D8] shadow-md border border-[#DFB6B2]'
                              : 'clay-inset-box hover:bg-white/80'
                          }`}
                        >
                          <div className="text-[11px] font-black">{mode.label}</div>
                          <div className={`text-[9px] font-bold ${isSelected ? 'text-[#DFB6B2]' : 'text-[#854F6C]'}`}>
                            +{mode.sparks} Sparks
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* 3D Inset Clay Timer Display */}
                  <div className="clay-inset-box p-5 rounded-2xl flex flex-col items-center justify-center relative overflow-hidden bg-white/70 border-2 border-[#ECD7CE]">
                    <div className="absolute top-2 left-3 flex items-center gap-1 text-[10px] font-bold text-[#854F6C]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-ping" />
                      <span>{streakSubject} Focus Block</span>
                    </div>

                    <div className="my-2">
                      <span className="text-4xl font-black text-[#2B124C] tracking-tight font-mono drop-shadow-sm">
                        {formatTimer(streakTimeRemaining)}
                      </span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full max-w-[260px] h-2 bg-[#DFB6B2]/40 rounded-full overflow-hidden mb-2">
                      <div
                        className="h-full bg-gradient-to-r from-orange-400 to-[#522B5B] rounded-full transition-all duration-300"
                        style={{
                          width: `${Math.min(
                            100,
                            Math.max(0, ((streakTimerDuration - streakTimeRemaining) / streakTimerDuration) * 100)
                          )}%`,
                        }}
                      />
                    </div>

                    {/* Ambient Sound Selector */}
                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="text-[9px] font-black text-[#854F6C] uppercase">Ambience:</span>
                      {[
                        { id: 'lofi', label: '🎧 Lo-Fi Beats' },
                        { id: 'library', label: '📚 Library' },
                        { id: 'rain', label: '🌧️ Rain' },
                        { id: 'off', label: '🔇 Off' },
                      ].map((snd) => (
                        <button
                          key={snd.id}
                          onClick={() => {
                            setStreakAmbientSound(snd.id as any);
                            showToast(`Study Ambience set to ${snd.label}!`);
                          }}
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md transition-all ${
                            streakAmbientSound === snd.id
                              ? 'bg-[#2B124C] text-[#FBE4D8]'
                              : 'bg-white/60 text-[#854F6C] hover:bg-white'
                          }`}
                        >
                          {snd.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Timer Controls */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsStreakTimerRunning(!isStreakTimerRunning)}
                      className="flex-1 py-2.5 rounded-xl text-xs font-black clay-pill-btn-active flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all cursor-pointer"
                    >
                      {isStreakTimerRunning ? (
                        <>
                          <Pause className="w-4 h-4 text-[#DFB6B2]" />
                          <span>Pause Timer</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 text-[#DFB6B2] fill-[#DFB6B2]" />
                          <span>Start Study Session</span>
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => {
                        setIsStreakTimerRunning(false);
                        setStreakTimeRemaining(streakTimerDuration);
                        showToast('Timer reset.');
                      }}
                      className="clay-pill-btn p-2.5 rounded-xl text-xs font-bold shrink-0 hover:scale-105 active:scale-95 transition-all"
                      title="Reset Timer"
                    >
                      <RotateCcw className="w-4 h-4 text-[#522B5B]" />
                    </button>

                    <button
                      onClick={() => {
                        setStreakTimeRemaining((prev) => prev + 5 * 60);
                        setStreakTimerDuration((prev) => prev + 5 * 60);
                        showToast('+5 Minutes added to session!');
                      }}
                      className="clay-pill-btn px-2.5 py-2.5 rounded-xl text-xs font-black shrink-0 hover:scale-105 active:scale-95 transition-all"
                      title="Add 5 Minutes"
                    >
                      +5m
                    </button>
                  </div>

                  {/* Manual Finish & Claim Streak Button */}
                  <button
                    onClick={handleClaimStreakManual}
                    className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 text-white font-black text-xs shadow-md hover:brightness-105 active:scale-98 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Flame className="w-4 h-4 fill-white" />
                    <span>Finish & Claim Today's Streak (+50 Sparks)</span>
                  </button>
                </div>

                {/* ========================================================= */}
                {/* CAMPUS OFFERS, REWARDS & DISCOUNT VOUCHERS */}
                {/* ========================================================= */}
                <div className="clay-card-warm p-4 space-y-3 border-2 border-[#DFB6B2]">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Gift className="w-4 h-4 text-rose-600" />
                      <h3 className="text-[14px] font-black text-[#2B124C]">
                        Streak rewards and vouchers
                      </h3>
                    </div>
                  </div>

                  {/* Voucher Category Tabs */}
                  <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
                    {[
                      { id: 'all', label: 'All Offers', icon: '🎁' },
                      { id: 'food', label: 'Food & Chai', icon: '☕' },
                      { id: 'books', label: 'Books', icon: '📚' },
                      { id: 'stationery', label: 'Stationery', icon: '✍️' },
                      { id: 'tech', label: 'Tech Pro', icon: '💻' },
                    ].map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setVoucherFilter(cat.id as any)}
                        className={`rounded-full px-2.5 py-1 text-[11px] font-black shrink-0 transition-all ${
                          voucherFilter === cat.id ? 'clay-pill-btn-active' : 'clay-pill-btn'
                        }`}
                      >
                        <span className="mr-1">{cat.icon}</span>
                        <span>{cat.label}</span>
                      </button>
                    ))}
                  </div>

                  {/* Vouchers Grid - Show 2 by default, rest on dropdown click */}
                  {(() => {
                    const filteredVouchersList = vouchers.filter((v) =>
                      voucherFilter === 'all' ? true : v.category === voucherFilter
                    );
                    const displayedVouchers = isVouchersExpanded
                      ? filteredVouchersList
                      : filteredVouchersList.slice(0, 2);

                    return (
                      <div className="space-y-2.5">
                        {displayedVouchers.map((voucher) => {
                          const canAfford = streakSparks >= voucher.sparksCost;
                          return (
                            <div
                              key={voucher.id}
                              className={`p-3 rounded-2xl bg-white/95 border-2 transition-all relative overflow-hidden ${
                                voucher.claimed
                                  ? 'border-emerald-400 shadow-sm'
                                  : 'border-[#ECD7CE] shadow-sm hover:border-[#DFB6B2]'
                              }`}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div className="flex items-start gap-2.5 flex-1 min-w-0">
                                  <VoucherBrandLogo brand={voucher.logoBrand} emoji={voucher.iconEmoji} />
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase bg-[#2B124C] text-[#FBE4D8]">
                                        {voucher.discount}
                                      </span>
                                      {voucher.badge && (
                                        <span className="px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-amber-100 text-amber-800">
                                          {voucher.badge}
                                        </span>
                                      )}
                                      <span className="text-[10px] font-bold text-[#854F6C] truncate">
                                        {voucher.partner}
                                      </span>
                                    </div>

                                    <h4 className="text-xs font-black text-[#2B124C] mt-1 leading-snug">
                                      {voucher.title}
                                    </h4>
                                    <p className="text-[10px] font-medium text-[#854F6C] mt-0.5 leading-snug">
                                      {voucher.description}
                                    </p>

                                    <div className="text-[9px] font-bold text-slate-400 mt-1">
                                      {voucher.validity}
                                    </div>
                                  </div>
                                </div>

                                <div className="flex flex-col items-end gap-1.5 shrink-0">
                                  <div className="flex items-center gap-1 text-[10px] font-black text-[#522B5B] bg-[#FBE4D8] px-2 py-0.5 rounded-lg border border-[#DFB6B2]/50">
                                    <Sparkles className="w-3 h-3 text-amber-500 fill-amber-400" />
                                    <span>{voucher.sparksCost}</span>
                                  </div>

                                  {voucher.claimed ? (
                                    <div className="flex flex-col items-end gap-1">
                                      <span className="text-[9px] font-black text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                                        <Check className="w-2.5 h-2.5" />
                                        Claimed
                                      </span>
                                      <button
                                        onClick={() => copyVoucherCode(voucher.promoCode)}
                                        className="clay-pill-btn text-[9px] font-black px-2 py-1 rounded-lg flex items-center gap-1 hover:scale-105 active:scale-95 transition-all cursor-pointer"
                                      >
                                        <Copy className="w-2.5 h-2.5 text-[#522B5B]" />
                                        <span>{copiedCode === voucher.promoCode ? 'Copied!' : 'Code'}</span>
                                      </button>
                                    </div>
                                  ) : (
                                    <button
                                      onClick={() => handleRedeemVoucher(voucher)}
                                      disabled={!canAfford}
                                      className={`px-3 py-1.5 rounded-xl text-[10px] font-black transition-all ${
                                        canAfford
                                          ? 'clay-pill-btn-active shadow hover:scale-105 active:scale-95 cursor-pointer'
                                          : 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                                      }`}
                                    >
                                      {canAfford ? 'Redeem 🎁' : 'Need Sparks'}
                                    </button>
                                  )}
                                </div>
                              </div>

                              {/* Claimed code banner */}
                              {voucher.claimed && (
                                <div className="mt-2 pt-2 border-t border-[#DFB6B2]/40 flex items-center justify-between bg-emerald-50/70 p-1.5 rounded-xl">
                                  <div className="flex items-center gap-1.5 text-[10px] font-black text-emerald-900">
                                    <Tag className="w-3 h-3 text-emerald-600" />
                                    <span>Coupon: <span className="font-mono bg-white px-1.5 py-0.5 rounded border border-emerald-200">{voucher.promoCode}</span></span>
                                  </div>
                                  <button
                                    onClick={() => copyVoucherCode(voucher.promoCode)}
                                    className="text-[9px] font-black text-emerald-700 hover:underline cursor-pointer"
                                  >
                                    {copiedCode === voucher.promoCode ? 'Copied! ✅' : 'Copy Coupon 📋'}
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })}

                        {/* Dropdown toggle to view remaining vouchers */}
                        {filteredVouchersList.length > 2 && (
                          <button
                            onClick={() => setIsVouchersExpanded(!isVouchersExpanded)}
                            className="w-full py-2.5 px-3 rounded-2xl clay-pill-btn text-xs font-bold text-[#2B124C] flex items-center justify-center gap-1.5 cursor-pointer hover:bg-white active:scale-98 transition-all shadow-xs"
                          >
                            <span>
                              {isVouchersExpanded
                                ? 'Show Less ▴'
                                : `View All (${filteredVouchersList.length}) Vouchers ▾`}
                            </span>
                          </button>
                        )}
                      </div>
                    );
                  })()}
                </div>
              </div>
            )}

            {/* 1A. BUDDY MATCHER & INSTAGRAM-STYLE DISCOVERY FEED */}
            {studySubView === 'matcher' && (
              <div className="space-y-3.5">
                {/* Instagram-Style Active Stories Bar */}
                <div className="clay-card p-3 space-y-1.5">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-[10px] font-black uppercase text-[#854F6C] tracking-wide flex items-center gap-1">
                      <span>📸</span> Campus Live Stories
                    </span>
                    <span className="text-[9px] font-bold text-[#10B981] flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#10B981] animate-ping" />
                      {peersList.length + 1} Studying Now
                    </span>
                  </div>

                  <div className="flex items-center gap-3 overflow-x-auto pb-1 pt-1 scrollbar-none">
                    {/* User's Own Story */}
                    <button
                      onClick={() => showToast('Your live study story is active! 📚 Topic: DSA Trees')}
                      className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group"
                    >
                      <div className="relative">
                        <div className="w-13 h-13 rounded-full p-0.5 bg-gradient-to-tr from-amber-400 via-[#DFB6B2] to-[#854F6C] shadow-sm group-hover:scale-105 transition-all">
                          <div className="w-full h-full rounded-full bg-[#2B124C] border-2 border-white flex items-center justify-center text-white text-base overflow-hidden">
                            <img
                              src="/assets/aistudio/image_1a4f2b80.png"
                              alt="Rahul"
                              className="w-full h-full object-cover p-1"
                            />
                          </div>
                        </div>
                        <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-[#10B981] text-white text-[10px] font-black flex items-center justify-center border-2 border-white shadow-xs">
                          +
                        </span>
                      </div>
                      <span className="text-[10px] font-black text-[#2B124C] max-w-[54px] truncate text-center">
                        Your Story
                      </span>
                    </button>

                    {/* Peer Stories with Instagram-style Gradient Ring */}
                    {peersList.map((peer) => (
                      <button
                        key={peer.id}
                        onClick={() => setActiveStoryPeer(peer)}
                        className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group"
                      >
                        <div className="relative">
                          {/* Animated Instagram-style Rainbow Ring */}
                          <div className="w-13 h-13 rounded-full p-[2.5px] bg-gradient-to-tr from-[#FF5E62] via-[#FF9966] to-[#854F6C] shadow-md group-hover:scale-108 transition-all">
                            <div className={`w-full h-full rounded-full ${peer.avatarBg} border-2 border-white flex items-center justify-center text-xl overflow-hidden`}>
                              <span>{peer.avatarEmoji}</span>
                            </div>
                          </div>
                          <span className="absolute -bottom-1 -right-1 text-[9px] px-1 py-0.2 rounded-full bg-[#2B124C] text-white font-black border border-white shadow-xs whitespace-nowrap">
                            {peer.activeStory?.statusBadge || 'Live'}
                          </span>
                        </div>
                        <span className="text-[10px] font-black text-[#2B124C] max-w-[58px] truncate text-center">
                          {peer.n.split(' ')[0]}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* View Mode Toggle: Instagram Feed vs Smart Matcher */}
                <div className="clay-card p-1.5 flex items-center gap-1">
                  <button
                    onClick={() => setBuddyViewMode('feed')}
                    className={`flex-1 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      buddyViewMode === 'feed' ? 'clay-pill-btn-active' : 'text-[#854F6C] hover:bg-white/40'
                    }`}
                  >
                    <span>📸</span>
                    <span>Buddy Discovery Feed</span>
                  </button>
                  <button
                    onClick={() => setBuddyViewMode('match')}
                    className={`flex-1 py-2 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                      buddyViewMode === 'match' ? 'clay-pill-btn-active' : 'text-[#854F6C] hover:bg-white/40'
                    }`}
                  >
                    <span>🎯</span>
                    <span>Smart Match Filter</span>
                  </button>
                </div>

                {/* 1. INSTAGRAM-STYLE BUDDY DISCOVERY FEED */}
                {buddyViewMode === 'feed' && (
                  <div className="space-y-3.5">
                    {peersList.map((peer) => {
                      const isConnected = peer.isConnected;
                      const isLiked = peer.isLiked;

                      return (
                        <div
                          key={peer.id}
                          className="clay-card-warm p-4 border-2 border-[#DFB6B2] space-y-3 relative overflow-hidden transition-all hover:shadow-lg"
                        >
                          {/* Card Header: Cartoon Avatar + Name + College/School */}
                          <div className="flex items-start justify-between gap-2.5">
                            <div className="flex items-center gap-3">
                              {/* Cartoon Avatar with Story Ring */}
                              <button
                                onClick={() => setActiveStoryPeer(peer)}
                                className="w-13 h-13 rounded-2xl p-0.5 bg-gradient-to-tr from-[#854F6C] via-[#DFB6B2] to-[#2B124C] shadow-md shrink-0 cursor-pointer hover:scale-105 transition-all text-center"
                              >
                                <div className={`w-full h-full rounded-[14px] ${peer.avatarBg} flex items-center justify-center text-2xl border-2 border-white`}>
                                  {peer.avatarEmoji}
                                </div>
                              </button>

                              <div>
                                <div className="flex items-center gap-1.5">
                                  <h3 className="font-black text-sm text-[#2B124C] leading-none m-0">
                                    {peer.n}
                                  </h3>
                                  <CheckCircle2 className="w-3.5 h-3.5 text-sky-500 fill-sky-100" />
                                </div>
                                <span className="text-[10px] font-bold text-[#854F6C] block mt-0.5">
                                  {peer.username}
                                </span>
                                <div className="flex items-center gap-1 text-[10px] font-extrabold text-[#522B5B] mt-0.5">
                                  <span>🏫</span>
                                  <span className="truncate max-w-[200px]">{peer.college}</span>
                                </div>
                              </div>
                            </div>

                            <span className="text-[9px] font-black px-2 py-0.5 rounded-full bg-white/80 text-[#854F6C] border border-[#DFB6B2]/40 shrink-0">
                              {peer.year}
                            </span>
                          </div>

                          {/* Live Activity Banner ("What they are doing right now") */}
                          <div className="bg-gradient-to-r from-[#522B5B]/10 via-[#854F6C]/10 to-[#DFB6B2]/20 border border-[#DFB6B2] p-2.5 rounded-2xl space-y-1">
                            <div className="flex items-center justify-between text-[10px] font-black text-[#522B5B]">
                              <span className="flex items-center gap-1">
                                <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse-live" />
                                <span>CURRENTLY STUDYING & WORKING ON</span>
                              </span>
                              <span className="text-[9px] text-[#854F6C]">Live Now</span>
                            </div>
                            <p className="text-xs font-bold text-[#2B124C] leading-snug m-0">
                              {peer.activity}
                            </p>
                          </div>

                          {/* Student Bio */}
                          <p className="text-xs text-[#522B5B] font-medium leading-relaxed m-0 bg-white/60 p-2.5 rounded-xl border border-white">
                            "{peer.bio}"
                          </p>

                          {/* Subject & Skill Badges */}
                          <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                            <span className="text-[10px] font-black text-[#854F6C] mr-1">Skills:</span>
                            {peer.sk.map((skill) => (
                              <span
                                key={skill}
                                className="text-[10px] font-black px-2 py-0.5 rounded-lg bg-[#2B124C] text-[#FBE4D8] shadow-xs"
                              >
                                #{skill}
                              </span>
                            ))}
                            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200 ml-auto flex items-center gap-1">
                              ⭐ {peer.rating} Rating
                            </span>
                          </div>

                          {/* Instagram-Style Action Bar */}
                          <div className="pt-2 border-t border-[#DFB6B2]/40 flex items-center justify-between gap-2">
                            {/* Like Button */}
                            <button
                              onClick={() => {
                                setPeersList((prev) =>
                                  prev.map((p) =>
                                    p.id === peer.id
                                      ? {
                                          ...p,
                                          isLiked: !p.isLiked,
                                          likesCount: p.isLiked ? p.likesCount - 1 : p.likesCount + 1,
                                        }
                                      : p
                                  )
                                );
                                showToast(
                                  isLiked
                                    ? `Unliked ${peer.n.split(' ')[0]}'s profile`
                                    : `❤️ Liked ${peer.n.split(' ')[0]}'s study profile!`
                                );
                              }}
                              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                                isLiked
                                  ? 'bg-rose-50 text-rose-600 border border-rose-200'
                                  : 'bg-white/80 text-[#522B5B] hover:bg-white'
                              }`}
                            >
                              <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-rose-500 text-rose-500' : 'text-[#854F6C]'}`} />
                              <span>{peer.likesCount}</span>
                            </button>

                            {/* Wave 👋 */}
                            <button
                              onClick={() => showToast(`Waved at ${peer.n.split(' ')[0]}! 👋 Notification sent to their phone.`)}
                              className="px-2.5 py-1.5 rounded-xl text-xs font-black bg-white/80 text-[#522B5B] hover:bg-white cursor-pointer active:scale-95 transition-all"
                              title="Send a quick study wave"
                            >
                              Wave 👋
                            </button>

                            {/* Connect Buddy 🤝 */}
                            <button
                              onClick={() => {
                                setPeersList((prev) =>
                                  prev.map((p) =>
                                    p.id === peer.id ? { ...p, isConnected: !p.isConnected } : p
                                  )
                                );
                                showToast(
                                  isConnected
                                    ? `Removed buddy connection with ${peer.n.split(' ')[0]}`
                                    : `🤝 Buddy Request Sent to ${peer.n}! Connected on CampusLoop.`
                                );
                              }}
                              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
                                isConnected
                                  ? 'bg-emerald-600 text-white shadow-xs'
                                  : 'clay-pill-btn-active'
                              }`}
                            >
                              {isConnected ? '✓ Connected' : 'Connect 🤝'}
                            </button>

                            {/* Join Study Pod 🎧 */}
                            <button
                              onClick={() => {
                                setActiveRoom({
                                  name: `Study Pod with ${peer.n.split(' ')[0]}`,
                                  subject: peer.sk[0] as SubjectType || 'DSA',
                                  timer: 25 * 60,
                                  isRunning: true,
                                  mode: 'study',
                                });
                                setStudySubView('room');
                                showToast(`🎧 Joined Virtual Study Pod with ${peer.n}!`);
                              }}
                              className="px-3 py-1.5 rounded-xl text-xs font-black bg-[#2B124C] text-[#FBE4D8] hover:bg-[#190019] cursor-pointer shadow-xs active:scale-95 transition-all"
                            >
                              Join Pod 🎧
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* 2. SMART MATCH FILTER VIEW */}
                {buddyViewMode === 'match' && (
                  <div className="space-y-3.5">
                    <div className="clay-card-warm p-4 flex items-center gap-3.5 border-2 border-[#DFB6B2]">
                      <div className="w-18 h-18 shrink-0 rounded-2xl overflow-hidden shadow-md border-2 border-white bg-white/50 p-0.5 animate-float">
                        <img src={clayStudent} alt="Clay Student" className="w-full h-full object-cover rounded-xl" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <span className="text-[10px] font-black uppercase text-[#854F6C] bg-white/80 px-2 py-0.5 rounded-full">
                          Criteria Matcher 🌸
                        </span>
                        <h2 className="text-[15px] font-black text-[#2B124C] mt-1 leading-tight">
                          Filter Compatible Buddies
                        </h2>
                        <p className="text-[11px] text-[#854F6C] font-semibold mt-0.5 leading-tight">
                          Match by semester, subject & study availability.
                        </p>
                      </div>
                    </div>

                    {/* Subject Selector */}
                    <div className="clay-card p-3.5 space-y-2">
                      <span className="text-xs font-black text-[#2B124C] block">Target Subject</span>
                      <div className="grid grid-cols-3 gap-2">
                        {SUBJECTS.map((s) => (
                          <button
                            key={s}
                            onClick={() => {
                              setSubj(s);
                              setMatches(null);
                            }}
                            className={`rounded-xl py-1.5 text-xs font-black transition-all cursor-pointer ${
                              subj === s ? 'clay-pill-btn-active' : 'clay-pill-btn'
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Mood & Slot */}
                    <div className="clay-card p-3.5 space-y-2">
                      <span className="text-xs font-black text-[#2B124C] block">Study Mood & Time</span>
                      <div className="flex flex-wrap gap-2">
                        {MOODS.map((m) => (
                          <button
                            key={m.id}
                            onClick={() => {
                              setMood(m.id);
                              setMatches(null);
                            }}
                            className={`rounded-full px-3 py-1.5 text-xs font-black transition-all cursor-pointer ${
                              mood === m.id ? 'clay-pill-btn-active' : 'clay-pill-btn'
                            }`}
                          >
                            <span>{m.emoji}</span> {m.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        const scored = PEERS.map((p) => {
                          let s = 40;
                          const why: string[] = [];
                          if (p.m.includes(mood)) s += 30, why.push(`Wants ${mood}`);
                          if (p.sk.includes(subj)) s += 25, why.push(`Strong in ${subj}`);
                          return { ...p, s: Math.min(s, 98), why };
                        }).sort((a, b) => (b.s || 0) - (a.s || 0));
                        setMatches(scored);
                        showToast('Found compatible peers on campus! 🌸');
                      }}
                      className="w-full py-3.5 rounded-2xl font-black text-[14px] text-white bg-gradient-to-r from-[#854F6C] via-[#522B5B] to-[#2B124C] border-2 border-[#522B5B] shadow-md active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Users className="w-4 h-4 text-[#DFB6B2]" />
                      <span>Find My Study Buddy</span>
                    </button>

                    {/* Matches Results */}
                    {matches && matches.length > 0 && (
                      <div className="space-y-2.5 pt-1">
                        <span className="text-xs font-black text-[#2B124C] block">Recommended Study Partners</span>
                        {matches.map((peer) => (
                          <div key={peer.id} className="clay-card p-3.5 flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5">
                              <span className="text-2xl p-2 rounded-xl bg-[#FBE4D8] border border-[#ECD7CE]">
                                {peer.avatarEmoji}
                              </span>
                              <div>
                                <div className="font-black text-sm text-[#2B124C]">{peer.n}</div>
                                <div className="text-[11px] text-[#854F6C] font-semibold">{peer.college} · {peer.year}</div>
                                <div className="text-[10px] text-[#522B5B] font-bold mt-0.5">{peer.sk.join(' · ')}</div>
                              </div>
                            </div>

                            <div className="text-right">
                              <span className="text-sm font-black text-[#1B4D3E] bg-[#D1E7DD] px-2 py-0.5 rounded-lg block mb-1">
                                {peer.s}%
                              </span>
                              <button
                                onClick={() => {
                                  setActiveRoom({
                                    name: `Study Pod with ${peer.n.split(' ')[0]}`,
                                    subject: subj,
                                    timer: 25 * 60,
                                    isRunning: true,
                                    mode: 'study',
                                  });
                                  setStudySubView('room');
                                  showToast(`Virtual Room started with ${peer.n}! 🎧`);
                                }}
                                className="clay-pill-btn-active text-[11px] font-black px-2.5 py-1 rounded-xl cursor-pointer"
                              >
                                Open Room
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* 1B. GROUP STUDY ROOMS (Virtual Room with Whiteboard & Pomodoro) */}
            {studySubView === 'room' && (
              <div className="space-y-3.5">
                {/* Pomodoro Timer Banner */}
                <div className="clay-card-purple text-white p-4 space-y-2.5 relative overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase text-[#DFB6B2] bg-white/10 px-2.5 py-0.5 rounded-full">
                      {activeRoom?.mode === 'break' ? '☕ 5-Min Rest Break' : '🧠 25-Min Pomodoro Sprint'}
                    </span>
                    <span className="text-xs font-bold text-[#A7F3D0] flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse-live" />
                      3 Peers Active
                    </span>
                  </div>

                  <div className="text-center py-1.5 bg-black/20 rounded-2xl border border-white/10">
                    <div className="text-3xl font-black font-mono tracking-tight text-[#FBE4D8]">
                      {formatTimer(activeRoom?.timer || 25 * 60)}
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-2 pt-1">
                    <button
                      onClick={() =>
                        setActiveRoom((prev) => ({
                          name: prev?.name || 'Study Pod',
                          subject: prev?.subject || 'DSA',
                          timer: prev?.timer || 25 * 60,
                          mode: prev?.mode || 'study',
                          isRunning: !prev?.isRunning,
                        }))
                      }
                      className="px-4 py-1 rounded-xl text-xs font-black bg-white text-[#2B124C] shadow-sm cursor-pointer"
                    >
                      {activeRoom?.isRunning ? 'Pause Timer' : 'Resume Timer'}
                    </button>
                    <button
                      onClick={() =>
                        setActiveRoom((prev) => ({
                          name: prev?.name || 'Study Pod',
                          subject: prev?.subject || 'DSA',
                          timer: 25 * 60,
                          mode: 'study',
                          isRunning: false,
                        }))
                      }
                      className="px-3 py-1 rounded-xl text-xs font-black bg-white/10 text-white border border-white/20 cursor-pointer"
                    >
                      Reset
                    </button>
                  </div>
                </div>

                {/* Shared Interactive Whiteboard */}
                <div className="clay-card p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-[#2B124C] flex items-center gap-1.5">
                      <PenTool className="w-4 h-4 text-[#854F6C]" />
                      <span>Shared Interactive Whiteboard</span>
                    </span>
                    <div className="flex items-center gap-1.5">
                      {['#2B124C', '#854F6C', '#10B981', '#F97316'].map((c) => (
                        <button
                          key={c}
                          onClick={() => setDrawColor(c)}
                          className={`w-4.5 h-4.5 rounded-full border-2 ${
                            drawColor === c ? 'border-black scale-110' : 'border-white'
                          }`}
                          style={{ backgroundColor: c }}
                        />
                      ))}
                      <button
                        onClick={clearCanvas}
                        className="text-[10px] font-bold text-[#854F6C] px-1.5 py-0.5 rounded bg-[#FBE4D8]"
                      >
                        Clear
                      </button>
                    </div>
                  </div>

                  {/* Canvas */}
                  <div className="w-full h-44 rounded-2xl bg-white border-2 border-[#ECD7CE] overflow-hidden relative cursor-crosshair">
                    <canvas
                      ref={canvasRef}
                      width={380}
                      height={176}
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                      onTouchStart={startDrawing}
                      onTouchMove={draw}
                      onTouchEnd={stopDrawing}
                      className="w-full h-full block"
                    />
                  </div>
                  <span className="text-[10px] text-[#854F6C] font-semibold block text-center">
                    Touch or drag cursor above to sketch architecture, math formulas & tree diagrams!
                  </span>
                </div>

                {/* Live Room Peer Chat */}
                <div className="clay-card p-3.5 space-y-2">
                  <span className="text-xs font-black text-[#2B124C] flex items-center gap-1.5">
                    <MessageCircle className="w-4 h-4 text-[#854F6C]" />
                    <span>Live Pod Chat & Doubts</span>
                  </span>

                  <div className="h-28 overflow-y-auto space-y-1.5 p-2 rounded-xl clay-inset-box text-xs">
                    {chatMessages.map((m, i) => (
                      <div key={i} className="flex items-baseline gap-1.5">
                        <span className="font-black text-[#2B124C] text-[11px]">{m.sender}:</span>
                        <span className="text-[#522B5B] text-[11px]">{m.text}</span>
                        <span className="text-[9px] text-slate-400 ml-auto">{m.time}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && chatInput.trim()) {
                          setChatMessages([
                            ...chatMessages,
                            { sender: 'You', text: chatInput.trim(), time: 'Just now' },
                          ]);
                          setChatInput('');
                        }
                      }}
                      placeholder="Type code or message..."
                      className="flex-1 px-3 py-1.5 text-xs rounded-xl clay-inset-box text-[#2B124C] focus:outline-none"
                    />
                    <button
                      onClick={() => {
                        if (chatInput.trim()) {
                          setChatMessages([
                            ...chatMessages,
                            { sender: 'You', text: chatInput.trim(), time: 'Just now' },
                          ]);
                          setChatInput('');
                        }
                      }}
                      className="clay-pill-btn-active px-3 py-1.5 rounded-xl text-xs font-black"
                    >
                      <Send className="w-3.5 h-3.5 text-[#DFB6B2]" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 1C. AI DOUBT SOLVER */}
            {studySubView === 'ai_solver' && (
              <div className="space-y-3.5">
                <div className="clay-card-warm p-4 space-y-2 border-2 border-[#DFB6B2]">
                  <div className="flex items-center gap-2">
                    <Bot className="w-5 h-5 text-[#522B5B]" />
                    <h3 className="font-black text-[15px] text-[#2B124C]">AI Academic Doubt & Code Solver</h3>
                  </div>
                  <p className="text-xs text-[#854F6C] font-semibold m-0">
                    Paste your homework problem, algorithmic doubt, or buggy code. AI provides step-by-step reasoning and matches campus seniors who solved it!
                  </p>
                </div>

                <div className="clay-card p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-[#2B124C]">Subject Topic</label>
                    <select
                      value={aiDoubtSubject}
                      onChange={(e) => setAiDoubtSubject(e.target.value as SubjectType)}
                      className="px-2.5 py-1 text-xs rounded-xl clay-inset-box text-[#2B124C] font-bold focus:outline-none"
                    >
                      {SUBJECTS.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>

                  <textarea
                    rows={4}
                    value={aiDoubtInput}
                    onChange={(e) => setAiDoubtInput(e.target.value)}
                    placeholder="e.g. How does Red-Black Tree rotation fix double-black, or paste code snippet getting Time Limit Exceeded..."
                    className="w-full p-3 text-xs rounded-2xl clay-inset-box text-[#2B124C] font-mono resize-none focus:outline-none"
                  />

                  <button
                    onClick={handleSolveWithAI}
                    disabled={aiSolving}
                    className="w-full clay-pill-btn-active py-3.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 cursor-pointer active:scale-95 shadow-md"
                  >
                    <Sparkles className="w-4 h-4 text-[#DFB6B2]" />
                    <span>{aiSolving ? 'Analyzing & Consulting Campus Database...' : 'Get Step-by-Step AI Breakdown'}</span>
                  </button>
                </div>

                {/* AI Solution Result Card */}
                {aiSolution && (
                  <div className="clay-card p-4 space-y-3 animate-pop">
                    <div className="flex items-center justify-between border-b border-[#F0D9D0] pb-2">
                      <span className="text-xs font-black text-[#1B4D3E] bg-[#D1E7DD] px-2.5 py-0.5 rounded-lg flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>AI Step-by-Step Solution</span>
                      </span>
                      <span className="text-[10px] text-[#854F6C] font-bold">{aiSolution.complexity}</span>
                    </div>

                    <div className="space-y-1.5">
                      <h4 className="text-xs font-black text-[#2B124C]">{aiSolution.concept}</h4>
                      {aiSolution.steps.map((st, i) => (
                        <p key={i} className="text-xs text-[#522B5B] leading-relaxed font-medium m-0">
                          {st}
                        </p>
                      ))}
                    </div>

                    <div className="bg-[#190019] text-[#DFB6B2] p-3 rounded-xl font-mono text-[11px] overflow-x-auto">
                      <pre className="m-0">{aiSolution.code}</pre>
                    </div>

                    {/* Community Peer Recommendation */}
                    <div className="bg-[#FFF6F0] p-3 rounded-2xl border-2 border-[#ECD7CE] space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-black text-[#2B124C] flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-[#854F6C]" />
                          <span>Campus Peer Recommendation</span>
                        </span>
                        <span className="text-[10px] font-black text-[#854F6C]">Same Topic Solved</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <div className="font-black text-xs text-[#2B124C]">{aiSolution.recommendedPeer.name}</div>
                          <div className="text-[10px] text-[#854F6C]">{aiSolution.recommendedPeer.bio}</div>
                        </div>
                        <button
                          onClick={() => {
                            setHub('community');
                            setCommunitySubView('doubts');
                            showToast(`Navigated to Community discussion with ${aiSolution.recommendedPeer.name}! 💡`);
                          }}
                          className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-xl shrink-0"
                        >
                          View Discussion
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* 1D. SMART STUDY PLANNER */}
            {studySubView === 'planner' && (
              <div className="space-y-3.5">
                <div className="clay-card-warm p-4 space-y-2 border-2 border-[#DFB6B2]">
                  <div className="flex items-center gap-2">
                    <CalendarDays className="w-5 h-5 text-[#522B5B]" />
                    <h3 className="font-black text-[15px] text-[#2B124C]">Smart Exam Study Planner</h3>
                  </div>
                  <p className="text-xs text-[#854F6C] font-semibold m-0">
                    Input your target subjects and exam window. CampusLoop builds an automatic day-by-day balanced study schedule with revision checkpoints!
                  </p>
                </div>

                {/* Planner Inputs */}
                <div className="clay-card p-4 space-y-3">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs font-black text-[#2B124C] block mb-1">Days Until Exams</label>
                      <input
                        type="number"
                        value={examDaysLeft}
                        onChange={(e) => setExamDaysLeft(Number(e.target.value))}
                        className="w-full px-3 py-1.5 text-xs rounded-xl clay-inset-box text-[#2B124C] font-bold focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-black text-[#2B124C] block mb-1">Daily Study Hours</label>
                      <input
                        type="number"
                        value={dailyHours}
                        onChange={(e) => setDailyHours(Number(e.target.value))}
                        className="w-full px-3 py-1.5 text-xs rounded-xl clay-inset-box text-[#2B124C] font-bold focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-black text-[#2B124C] block mb-1.5">Target Subjects</label>
                    <div className="flex flex-wrap gap-1.5">
                      {SUBJECTS.map((s) => {
                        const isIncluded = plannerSubjects.includes(s);
                        return (
                          <button
                            key={s}
                            onClick={() => {
                              if (isIncluded) {
                                setPlannerSubjects(plannerSubjects.filter((x) => x !== s));
                              } else {
                                setPlannerSubjects([...plannerSubjects, s]);
                              }
                            }}
                            className={`px-3 py-1 text-xs font-black rounded-xl transition-all ${
                              isIncluded ? 'clay-pill-btn-active' : 'clay-pill-btn'
                            }`}
                          >
                            {s}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <button
                    onClick={handleGeneratePlan}
                    className="w-full clay-pill-btn-active py-3.5 rounded-2xl font-black text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md"
                  >
                    <Calendar className="w-4 h-4 text-[#DFB6B2]" />
                    <span>Generate Structured Weekly Plan</span>
                  </button>
                </div>

                {/* Generated Schedule */}
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between px-1">
                    <span className="text-xs font-black text-[#2B124C]">Generated Weekly Schedule</span>
                    <span className="text-[10px] font-bold text-[#854F6C]">
                      Completed: {generatedPlan.filter((p) => p.completed).length}/{generatedPlan.length}
                    </span>
                  </div>

                  {generatedPlan.map((item, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setGeneratedPlan(
                          generatedPlan.map((p, i) => (i === idx ? { ...p, completed: !p.completed } : p))
                        );
                        showToast(item.completed ? 'Goal marked incomplete' : 'Goal completed! Keep going! 🎯');
                      }}
                      className={`clay-card p-3 flex items-center justify-between gap-3 cursor-pointer transition-all ${
                        item.completed ? 'opacity-65 bg-[#FAF4F0]' : 'hover:scale-[1.01]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <button className="text-lg text-[#522B5B]">
                          {item.completed ? <CheckSquare className="w-5 h-5 text-[#10B981]" /> : <Square className="w-5 h-5 text-[#854F6C]" />}
                        </button>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-xs font-black text-[#2B124C]">{item.day}</span>
                            <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-[#E2D9F3] text-[#522B5B]">
                              {item.subject}
                            </span>
                          </div>
                          <div className="text-xs text-[#522B5B] font-semibold mt-0.5">{item.topic}</div>
                        </div>
                      </div>

                      <span className="text-[10px] font-black text-[#854F6C] px-2 py-1 rounded-lg bg-[#FBE4D8]">
                        {item.duration}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* 2. HUB: LIBRARY, FLASHCARDS & PEER TUTORS                 */}
        {/* ========================================================= */}
        {hub === 'notes' && (
          <div className="space-y-3.5 animate-fadeIn">
            {/* Sub-tabs */}
            <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'marketplace', label: 'Library', icon: '📚' },
                { id: 'flashcards', label: 'Flashcards', icon: '🃏' },
                { id: 'tutors', label: 'Peer Tutors', icon: '🎓' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setNotesSubView(tab.id as NotesSubView)}
                  className={`rounded-full px-3.5 py-1.5 text-xs font-black shrink-0 transition-all cursor-pointer flex items-center gap-1.5 ${
                    notesSubView === tab.id ? 'clay-pill-btn-active' : 'clay-pill-btn'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* 2A. CAMPUS LIBRARY (NOTES) */}
            {notesSubView === 'marketplace' && (
              <div className="space-y-3">
                <div className="clay-card-warm p-4 space-y-1.5 border-2 border-[#DFB6B2]">
                  <h3 className="font-black text-[15px] text-[#2B124C]">Campus Library</h3>
                  <p className="text-xs text-[#854F6C] font-semibold m-0">
                    High-scoring notes vetted by senior university toppers. Includes interactive revision flashcards!
                  </p>
                </div>

                {NOTES_LIBRARY.map((note) => (
                  <div key={note.id} className="clay-card p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase tracking-wider text-[#522B5B] bg-[#E2D9F3] px-2.5 py-0.5 rounded-full">
                        {note.subject}
                      </span>
                      <div className="flex items-center gap-1 text-xs font-black text-amber-700 bg-amber-100 px-2 py-0.5 rounded-lg">
                        <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                        <span>{note.rating} ({note.reviews})</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-black text-[15px] text-[#2B124C] leading-snug">{note.title}</h4>
                      <div className="text-xs text-[#854F6C] font-semibold mt-1">
                        Author: {note.author} ({note.authorYear}) · {note.pages} Pages · {note.downloads} Downloads
                      </div>
                    </div>

                    <div className="pt-1 border-t border-[#F0D9D0]">
                      <button
                        onClick={() => {
                          setSelectedNote(note);
                          setNotesSubView('flashcards');
                          setActiveFlashcardIdx(0);
                          setFlashcardFlipped(false);
                          showToast(`Loaded ${note.flashcards.length} revision flashcards! 🃏`);
                        }}
                        className="w-full clay-pill-btn-active py-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
                      >
                        <BookMarked className="w-4 h-4 text-[#DFB6B2]" />
                        <span>Practice Flashcards ({note.flashcards.length} Cards)</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 2B. INTERACTIVE FLASHCARDS */}
            {notesSubView === 'flashcards' && (
              <div className="space-y-3.5 animate-fadeIn">
                <div className="flex items-center justify-between px-1">
                  <div>
                    <h3 className="text-sm font-black text-[#2B124C]">Interactive Study Flashcards</h3>
                    <p className="text-[11px] text-[#854F6C] m-0">Card {activeFlashcardIdx + 1} of {selectedNote.flashcards.length}</p>
                  </div>
                  <span className="text-xs font-bold text-[#522B5B] bg-[#E2D9F3] px-2.5 py-1 rounded-full">
                    {selectedNote.subject}
                  </span>
                </div>

                {/* Flip Card Widget */}
                <div
                  onClick={() => setFlashcardFlipped(!flashcardFlipped)}
                  className={`clay-card p-6 min-h-[220px] flex flex-col justify-between text-center cursor-pointer transition-all duration-300 transform ${
                    flashcardFlipped ? 'bg-gradient-to-br from-[#FFF8F3] to-[#FDE8DF] border-[#522B5B]' : 'hover:scale-[1.01]'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-bold text-[#854F6C]">
                    <span>{flashcardFlipped ? 'Answer Side' : 'Question Side'}</span>
                    <span className="flex items-center gap-1 text-[10px] bg-white px-2 py-0.5 rounded-full border border-[#DFB6B2]">
                      <FlipHorizontal className="w-3 h-3" /> Tap to Flip
                    </span>
                  </div>

                  <div className="my-auto py-4">
                    {flashcardFlipped ? (
                      <p className="text-sm font-bold text-[#2B124C] leading-relaxed">
                        {selectedNote.flashcards[activeFlashcardIdx].a}
                      </p>
                    ) : (
                      <h4 className="text-base font-black text-[#2B124C] leading-snug">
                        {selectedNote.flashcards[activeFlashcardIdx].q}
                      </h4>
                    )}
                  </div>

                  <span className="text-[11px] font-bold text-[#854F6C]">
                    {flashcardFlipped ? 'Great recall! Tap to flip back.' : 'Think of the answer, then tap to check!'}
                  </span>
                </div>

                {/* Card Controls */}
                <div className="flex items-center justify-between gap-3">
                  <button
                    disabled={activeFlashcardIdx === 0}
                    onClick={() => {
                      setActiveFlashcardIdx((prev) => Math.max(0, prev - 1));
                      setFlashcardFlipped(false);
                    }}
                    className="clay-pill-btn flex-1 py-2.5 rounded-xl text-xs font-black disabled:opacity-40"
                  >
                    Previous
                  </button>

                  <button
                    disabled={activeFlashcardIdx >= selectedNote.flashcards.length - 1}
                    onClick={() => {
                      setActiveFlashcardIdx((prev) => Math.min(selectedNote.flashcards.length - 1, prev + 1));
                      setFlashcardFlipped(false);
                    }}
                    className="clay-pill-btn-active flex-1 py-2.5 rounded-xl text-xs font-black disabled:opacity-40"
                  >
                    Next Card
                  </button>
                </div>
              </div>
            )}

            {/* 2C. PEER TUTORING (CONSOLIDATED INTO LIBRARY) */}
            {notesSubView === 'tutors' && (
              <div className="space-y-3.5 animate-fadeIn">
                <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
                  {[
                    { id: 'browse', label: 'Top Tutors', icon: '🎓' },
                    { id: 'wallet', label: 'Points & Wallet', icon: '🪙' },
                    { id: 'become_tutor', label: 'Become a Tutor', icon: '⭐' },
                  ].map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setTutorsSubView(tab.id as TutorsSubView)}
                      className={`rounded-full px-3 py-1.5 text-xs font-black shrink-0 transition-all cursor-pointer flex items-center gap-1 ${
                        tutorsSubView === tab.id ? 'clay-pill-btn-active' : 'clay-pill-btn'
                      }`}
                    >
                      <span>{tab.icon}</span>
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </div>

                {/* 2C-1. BROWSE TUTORS */}
                {tutorsSubView === 'browse' && (
                  <div className="space-y-3">
                    <div className="clay-card-warm p-4 space-y-1.5 border-2 border-[#DFB6B2]">
                      <h3 className="font-black text-[15px] text-[#2B124C]">1-on-1 Peer Tutoring</h3>
                      <p className="text-xs text-[#854F6C] font-semibold m-0">
                        Learn difficult topics directly from high-scoring college peers. Pay using earned study points!
                      </p>
                    </div>

                    {TUTORS.map((tutor) => (
                      <div key={tutor.id} className="clay-card p-4 space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <span className="text-2xl p-2 rounded-2xl bg-[#FBE4D8] border border-[#ECD7CE]">
                              {tutor.avatarEmoji}
                            </span>
                            <div>
                              <div className="font-black text-sm text-[#2B124C]">{tutor.name}</div>
                              <div className="text-xs text-[#854F6C] font-semibold">{tutor.year}</div>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="text-xs font-black text-amber-700 bg-amber-100 px-2 py-0.5 rounded-lg flex items-center gap-1">
                              <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                              <span>{tutor.rating}</span>
                            </span>
                            <span className="text-[10px] text-[#854F6C] font-bold block mt-0.5">
                              {tutor.sessionsCompleted} sessions
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-[#522B5B] font-medium leading-relaxed m-0">{tutor.bio}</p>

                        <div className="flex flex-wrap gap-1.5">
                          {tutor.specialty.map((s) => (
                            <span key={s} className="text-[10px] font-black px-2 py-0.5 rounded-full bg-[#E2D9F3] text-[#522B5B]">
                              {s}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center justify-between pt-1 border-t border-[#F0D9D0]">
                          <span className="text-xs font-black text-[#2B124C]">
                            {tutor.hourlyPoints} Pts <span className="text-[10px] text-[#854F6C] font-normal">/ hour</span>
                          </span>

                          <button
                            onClick={() => {
                              setSelectedTutor(tutor);
                              setBookingSlot(tutor.availableSlots[0]);
                            }}
                            className="clay-pill-btn-active text-xs font-black px-3.5 py-1.5 rounded-xl cursor-pointer active:scale-95"
                          >
                            Book 1-on-1 Session
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 2C-2. POINTS & CERTIFICATE WALLET */}
                {tutorsSubView === 'wallet' && (
                  <div className="space-y-3.5">
                    <div className="clay-card-purple text-white p-5 space-y-2 relative overflow-hidden">
                      <span className="text-[10px] font-black uppercase text-[#DFB6B2] bg-white/10 px-2.5 py-0.5 rounded-full">
                        Campus Credits Balance
                      </span>
                      <div className="text-3xl font-black font-mono text-[#FBE4D8]">{userPoints} Points</div>
                      <p className="text-xs text-[#DFB6B2] m-0">
                        Earn points by answering doubts and tutoring peers. Redeem for 1-on-1 sessions!
                      </p>
                    </div>

                    <div className="clay-card p-4 space-y-2.5">
                      <span className="text-xs font-black text-[#2B124C]">Upcoming Booked Sessions</span>
                      {bookedSessions.length === 0 ? (
                        <p className="text-xs text-[#854F6C] m-0 py-2 text-center">No booked sessions yet. Browse tutors to schedule!</p>
                      ) : (
                        bookedSessions.map((b, i) => (
                          <div key={i} className="p-2.5 rounded-xl bg-[#FFF6F0] border border-[#ECD7CE] flex items-center justify-between">
                            <div>
                              <div className="text-xs font-black text-[#2B124C]">{b.tutor} · {b.subject}</div>
                              <div className="text-[10px] text-[#854F6C]">{b.time}</div>
                            </div>
                            <span className="text-[10px] font-black text-[#1B4D3E] bg-[#D1E7DD] px-2 py-0.5 rounded-md">
                              Confirmed
                            </span>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Official Peer Tutor Certificate Card */}
                    <div className="clay-card-warm p-4 space-y-2 border-2 border-amber-300">
                      <div className="flex items-center gap-2">
                        <Award className="w-5 h-5 text-amber-700" />
                        <span className="text-xs font-black text-[#2B124C]">Institute Peer Tutoring Certificate</span>
                      </div>
                      <p className="text-xs text-[#854F6C] font-semibold m-0">
                        Complete 5 verified peer tutoring sessions to receive an official Dean-accredited Certificate of Academic Mentorship!
                      </p>
                      <button
                        onClick={() => showToast('Certificate progress: 2/5 sessions completed! 🏆')}
                        className="clay-pill-btn px-3 py-1.5 rounded-xl text-xs font-black"
                      >
                        View Mentorship Progress
                      </button>
                    </div>
                  </div>
                )}

                {/* 2C-3. BECOME A TUTOR */}
                {tutorsSubView === 'become_tutor' && (
                  <div className="clay-card p-4 space-y-3">
                    <h3 className="font-black text-[15px] text-[#2B124C]">Register as a Campus Tutor</h3>
                    <p className="text-xs text-[#854F6C] font-semibold">
                      Share your academic mastery, help classmates pass tricky courses, and earn points & mentorship certificates.
                    </p>

                    <div className="space-y-2">
                      <div>
                        <label className="text-xs font-black text-[#2B124C] block mb-1">Strongest Subjects</label>
                        <input
                          type="text"
                          placeholder="e.g. DSA, Operating Systems, Java"
                          className="w-full px-3 py-2 text-xs rounded-xl clay-inset-box text-[#2B124C] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-black text-[#2B124C] block mb-1">Subject Grade / CGPA</label>
                        <input
                          type="text"
                          placeholder="e.g. A+ in DSA (CGPA 9.2)"
                          className="w-full px-3 py-2 text-xs rounded-xl clay-inset-box text-[#2B124C] focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="text-xs font-black text-[#2B124C] block mb-1">Preferred Hourly Rate (Points)</label>
                        <input
                          type="number"
                          placeholder="e.g. 40"
                          className="w-full px-3 py-2 text-xs rounded-xl clay-inset-box text-[#2B124C] focus:outline-none"
                        />
                      </div>
                    </div>

                    <button
                      onClick={() => showToast('Tutor application submitted for Academic Head verification! 🎓')}
                      className="w-full clay-pill-btn-active py-3 rounded-2xl font-black text-xs cursor-pointer"
                    >
                      Submit Tutor Application
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* 4. HUB: CAMPUS FEED & HACKATHONS                          */}
        {/* ========================================================= */}
        {hub === 'feed' && (
          <div className="space-y-3.5 animate-fadeIn">
            <div className="flex items-center justify-between px-1">
              <div>
                <h2 className="text-[16px] font-black text-[#2B124C]">Live Campus Feed</h2>
                <p className="text-[11px] text-[#854F6C] font-semibold m-0">Verified hackathons, workshops & internships</p>
              </div>
            </div>

            <div className="space-y-3">
              {events.map((e) => (
                <div key={e.id} className="clay-card p-4 space-y-3 border-2 border-[#ECD7CE] hover:border-[#DFB6B2] transition-all">
                  <div className="flex items-start gap-3">
                    {/* Left Corner Logo */}
                    {e.logoType && <HackathonLogo type={e.logoType} />}

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wide ${e.tagBg} ${e.tagColor}`}>
                          {e.tag}
                        </span>
                        <span className="text-[11px] font-bold text-[#854F6C]">{e.t}</span>
                      </div>

                      <h3 className="font-black text-sm text-[#2B124C] leading-snug">{e.title}</h3>
                      <div className="text-[11px] text-[#854F6C] font-semibold mt-0.5">{e.organizer}</div>
                    </div>
                  </div>

                  {/* Subheadings: Eligibility, Where/Mode, Prize, Deadline */}
                  <div className="p-2.5 rounded-xl bg-[#FFF6F0] border border-[#ECD7CE] space-y-1.5 text-xs">
                    <div className="flex items-start gap-1.5 text-[11px]">
                      <span className="font-black text-[#2B124C] shrink-0">🎓 Eligibility:</span>
                      <span className="text-[#522B5B] font-medium">{e.eligibility}</span>
                    </div>
                    <div className="flex items-start gap-1.5 text-[11px]">
                      <span className="font-black text-[#2B124C] shrink-0">📍 Where:</span>
                      <span className="text-[#522B5B] font-medium">{e.where}</span>
                    </div>
                    {e.prizePool && (
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <span className="font-black text-[#2B124C] shrink-0">🏆 Prize Pool:</span>
                        <span className="text-[#1B4D3E] font-bold">{e.prizePool}</span>
                      </div>
                    )}
                    {e.deadline && (
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <span className="font-black text-[#2B124C] shrink-0">⏰ Deadline:</span>
                        <span className="text-[#B45309] font-bold">{e.deadline}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-[#F0D9D0]">
                    <span className="text-xs text-[#854F6C] font-bold"><strong>{e.going}</strong> students registered</span>
                    <button
                      onClick={() => showToast(`Registered for ${e.title}! Calendar invite & checklist sent! 🚀`)}
                      className="clay-pill-btn-active text-xs font-black px-3.5 py-1.5 rounded-xl cursor-pointer hover:scale-105 active:scale-95 transition-all"
                    >
                      Register Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* 5. HUB: COMMUNITY, DOUBTS & MULTIPLAYER QUIZ              */}
        {/* ========================================================= */}
        {hub === 'community' && (
          <div className="space-y-3.5 animate-fadeIn">
            {/* Sub-tabs */}
            <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'doubts', label: 'Doubts & Q&A', icon: '💬' },
                { id: 'teams', label: 'Hackathon Teams', icon: '🚀' },
                { id: 'quiz', label: 'Quiz Arena', icon: '🎮' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setCommunitySubView(tab.id as CommunitySubView)}
                  className={`rounded-full px-3 py-1.5 text-xs font-black shrink-0 transition-all cursor-pointer flex items-center gap-1 ${
                    communitySubView === tab.id ? 'clay-pill-btn-active' : 'clay-pill-btn'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                </button>
              ))}
            </div>

            {/* 5A. DOUBTS & Q&A */}
            {communitySubView === 'doubts' && (
              <div className="space-y-3">
                {posts.map((post) => (
                  <div key={post.id} className="clay-card p-4 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{post.avatarEmoji}</span>
                        <div>
                          <div className="text-xs font-black text-[#2B124C]">{post.author}</div>
                          <div className="text-[10px] text-[#854F6C]">{post.authorYear}</div>
                        </div>
                      </div>
                      <span className="text-[10px] font-black uppercase text-[#522B5B] bg-[#FBE4D8] px-2 py-0.5 rounded-full border border-[#ECD7CE]">
                        #{post.subject}
                      </span>
                    </div>

                    <h4 className="font-black text-sm text-[#2B124C]">{post.title}</h4>
                    <p className="text-xs text-[#522B5B] leading-relaxed font-medium m-0">{post.desc}</p>

                    {post.replies.map((r, idx) => (
                      <div key={idx} className="p-2.5 rounded-xl bg-[#FFF6F0] border border-[#ECD7CE] space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-black text-[#2B124C]">{r.author}</span>
                          {r.isVerifiedHelpful && (
                            <span className="text-[9px] font-black text-[#1B4D3E] bg-[#D1E7DD] px-1.5 py-0.5 rounded-md">
                              ✓ Verified Answer
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#522B5B] m-0">{r.text}</p>
                      </div>
                    ))}

                    <div className="flex items-center justify-between pt-1 border-t border-[#F0D9D0]">
                      <button
                        onClick={() => {
                          setPosts(
                            posts.map((p) =>
                              p.id === post.id
                                ? { ...p, hasUpvoted: !p.hasUpvoted, upvotes: p.upvotes + (p.hasUpvoted ? -1 : 1) }
                                : p
                            )
                          );
                        }}
                        className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-black ${
                          post.hasUpvoted ? 'bg-[#522B5B] text-white' : 'clay-pill-btn'
                        }`}
                      >
                        <ThumbsUp className="w-3.5 h-3.5" />
                        <span>{post.upvotes} Upvotes</span>
                      </button>
                      <span className="text-xs text-[#854F6C] font-bold">{post.replies.length} Explanations</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 5B. HACKATHON TEAM FINDER */}
            {communitySubView === 'teams' && (
              <div className="space-y-3">
                {teams.map((t) => (
                  <div
                    key={t.id}
                    className="clay-card p-4 space-y-3 border-2 border-[#ECD7CE] hover:border-[#DFB6B2] transition-all"
                  >
                    {/* Top Row: Left Hackathon Logo + Heading + Members Badge */}
                    <div className="flex items-start gap-3">
                      {/* Left Corner: Hackathon Logo Badge */}
                      <HackathonLogo type={t.logoType} />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <span className="text-[10px] font-black uppercase text-[#522B5B] bg-[#E2D9F3] px-2.5 py-0.5 rounded-full tracking-wide">
                            {t.event}
                          </span>
                          <span className="text-xs font-bold text-[#854F6C] shrink-0">
                            Members: {t.membersCount}/{t.maxMembers}
                          </span>
                        </div>

                        {/* Bold Hackathon Heading */}
                        <h4 className="font-black text-sm text-[#2B124C] leading-snug">
                          {t.hackathonName || t.event}
                        </h4>
                        <div className="text-[11px] font-extrabold text-[#522B5B] mt-0.5">
                          Project: {t.title}
                        </div>
                      </div>
                    </div>

                    {/* Project Description */}
                    <p className="text-xs text-[#854F6C] font-medium leading-relaxed m-0">
                      {t.desc}
                    </p>

                    {/* Subheadings: Eligibility, Location/Mode, Prize Pool, Deadline */}
                    <div className="p-2.5 rounded-xl bg-[#FFF6F0] border border-[#ECD7CE] space-y-1.5 text-xs">
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <span className="font-black text-[#2B124C] shrink-0">🎓 Eligibility:</span>
                        <span className="text-[#522B5B] font-medium">{t.eligibility}</span>
                      </div>
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <span className="font-black text-[#2B124C] shrink-0">📍 Where / Mode:</span>
                        <span className="text-[#522B5B] font-medium">{t.location}</span>
                      </div>
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <span className="font-black text-[#2B124C] shrink-0">🏆 Prize & Perks:</span>
                        <span className="text-[#1B4D3E] font-bold">{t.prizePool}</span>
                      </div>
                      <div className="flex items-start gap-1.5 text-[11px]">
                        <span className="font-black text-[#2B124C] shrink-0">⏰ Deadline:</span>
                        <span className="text-[#B45309] font-bold">{t.deadline}</span>
                      </div>
                    </div>

                    {/* Roles Needed */}
                    <div className="space-y-1.5 pt-1 border-t border-[#F0D9D0]">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-[#854F6C] tracking-wider">
                          ROLES NEEDED:
                        </span>
                        <span className="text-[10px] text-[#854F6C] font-semibold">
                          Lead: {t.creator}
                        </span>
                      </div>

                      <div className="flex flex-wrap gap-1.5">
                        {t.rolesNeeded.map((r) => {
                          const isApplied = t.appliedRoles?.includes(r) || t.applied;
                          return (
                            <button
                              key={r}
                              onClick={() => {
                                setTeams(
                                  teams.map((x) =>
                                    x.id === t.id
                                      ? {
                                          ...x,
                                          appliedRoles: [...(x.appliedRoles || []), r],
                                          applied: true,
                                        }
                                      : x
                                  )
                                );
                                showToast(`Applied for ${r} role on ${t.hackathonName}! Team lead notified 🚀`);
                              }}
                              className={`text-[10px] font-black px-2.5 py-1 rounded-xl transition-all cursor-pointer ${
                                isApplied
                                  ? 'bg-[#10B981] text-white shadow-sm'
                                  : 'bg-[#FBE4D8] text-[#522B5B] border border-[#ECD7CE] hover:bg-[#DFB6B2] active:scale-95'
                              }`}
                            >
                              {isApplied ? `✓ Applied for ${r}` : `+ Apply as ${r}`}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* 5C. MULTIPLAYER QUIZ ARENA */}
            {communitySubView === 'quiz' && (
              <div className="clay-card-purple text-white p-5 space-y-3 relative overflow-hidden">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl overflow-hidden shrink-0 border-2 border-[#DFB6B2] bg-white/20 p-0.5 animate-float">
                    <img src={trophyMascot} alt="Trophy" className="w-full h-full object-cover rounded-xl" />
                  </div>
                  <div>
                    <h3 className="font-black text-base text-white m-0">Live Peer Quiz Arena</h3>
                    <p className="text-xs text-[#DFB6B2] mt-0.5 mb-0 font-medium">
                      Compete 1v1 in 5-minute timed battles to earn study points!
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => showToast('Matchmaking arena: Aarav and Riya challenged! Starting in 5s... 🎮')}
                  className="w-full clay-pill-btn-active py-3 rounded-2xl font-black text-xs cursor-pointer"
                >
                  Find 1v1 Battle Opponent
                </button>
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* 6. HUB: PROFILE (Instagram-Style Cartoon Avatar & Academic Showcase) */}
        {/* ========================================================= */}
        {hub === 'profile' && (
          <div className="space-y-3.5 animate-fadeIn">
            {/* Instagram-Style Top Profile Card matching attachment */}
            <div className="clay-card-warm p-4 border-2 border-[#DFB6B2] text-center relative overflow-hidden shadow-lg">
              {/* Centered Large Circular Cartoon Avatar with Glow Ring */}
              <div className="relative inline-block mx-auto mt-1 mb-1">
                <div className="w-24 h-24 rounded-full p-[3px] bg-gradient-to-tr from-[#FF5E62] via-[#DFB6B2] to-[#854F6C] shadow-xl">
                  <div className="w-full h-full rounded-full bg-[#190019] border-2 border-white flex items-center justify-center overflow-hidden">
                    <img
                      src={userProfile.avatar}
                      alt={userProfile.name}
                      className="w-full h-full object-cover p-1.5"
                    />
                  </div>
                </div>
                <button
                  onClick={() => setShowEditProfileModal(true)}
                  className="absolute bottom-0 right-0 w-7 h-7 rounded-full bg-[#522B5B] text-white border-2 border-white flex items-center justify-center shadow-md text-xs hover:scale-110 active:scale-95 transition-all cursor-pointer"
                  title="Change Cartoon Avatar"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Verified Student Name */}
              <div className="flex items-center justify-center gap-1.5 mt-2">
                <h2 className="text-xl font-black text-[#2B124C] m-0 leading-tight">
                  {userProfile.name}
                </h2>
                <div className="w-4 h-4 rounded-full bg-[#0095F6] flex items-center justify-center text-white text-[10px] font-black shadow-xs">
                  ✓
                </div>
              </div>

              {/* Carousel Indicator Dots (matching screenshot) */}
              <div className="flex items-center justify-center gap-1 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#2B124C]" />
                <span className="w-1.5 h-1.5 rounded-full bg-[#DFB6B2]" />
              </div>

              {/* Handle & College */}
              <span className="text-xs font-bold text-[#854F6C] block mt-1">
                {userProfile.username} · {userProfile.year}
              </span>
              <p className="text-[11px] font-extrabold text-[#522B5B] mt-0.5 flex items-center justify-center gap-1">
                <span>🏫</span>
                <span>{userProfile.college}</span>
              </p>

              {/* 3-Column Stats Row (matching 291 POSTS | 6,188 FOLLOWERS | 793 FOLLOWING in screenshot) */}
              <div className="flex items-center justify-around py-3.5 mt-3 border-y border-[#DFB6B2]/50 text-center">
                <div>
                  <div className="text-xl font-black text-[#2B124C] leading-none">
                    {userProfile.leetcodeSolved}
                  </div>
                  <div className="text-[10px] font-black uppercase text-[#854F6C] tracking-wider mt-1">
                    LeetCode
                  </div>
                </div>
                <div className="h-8 w-px bg-[#DFB6B2]/70" />
                <div
                  onClick={() => setShowRemoveBuddyModal(true)}
                  className="cursor-pointer group"
                  title="Click to view & manage buddies"
                >
                  <div className="text-xl font-black text-[#2B124C] leading-none group-hover:text-rose-600 transition-colors">
                    {peersList.filter((p) => p.isConnected).length}
                  </div>
                  <div className="text-[10px] font-black uppercase text-[#854F6C] tracking-wider mt-1 group-hover:text-rose-600">
                    Buddies
                  </div>
                </div>
                <div className="h-8 w-px bg-[#DFB6B2]/70" />
                <div
                  onClick={() => setShowVouchersModal(true)}
                  className="cursor-pointer group"
                  title="Click to view unlocked vouchers"
                >
                  <div className="text-xl font-black text-[#2B124C] leading-none group-hover:text-amber-600 transition-colors">
                    {claimedVouchers.length + 3}
                  </div>
                  <div className="text-[10px] font-black uppercase text-[#854F6C] tracking-wider mt-1 group-hover:text-amber-600">
                    Vouchers
                  </div>
                </div>
              </div>

              {/* Action Buttons: Edit Profile & Manage Buddies */}
              <div className="flex items-center gap-2 mt-3">
                <button
                  onClick={() => setShowEditProfileModal(true)}
                  className="flex-1 py-2 rounded-xl bg-white border border-[#DFB6B2] text-[#2B124C] font-black text-xs hover:bg-slate-50 transition-all cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit Profile</span>
                </button>
                <button
                  onClick={() => setShowRemoveBuddyModal(true)}
                  className="flex-1 py-2 rounded-xl bg-white border border-[#DFB6B2] text-[#2B124C] font-black text-xs hover:bg-slate-50 transition-all cursor-pointer shadow-xs flex items-center justify-center gap-1.5"
                >
                  <UserX className="w-3.5 h-3.5 text-rose-500" />
                  <span>Remove Buddy</span>
                </button>
              </div>

              {/* Profile Bio */}
              <div className="mt-3 bg-white/70 p-3 rounded-2xl border border-white text-left">
                <span className="text-[10px] font-black uppercase text-[#854F6C] block">Campus Bio</span>
                <p className="text-xs font-semibold text-[#2B124C] mt-1 leading-relaxed m-0">
                  {userProfile.bio}
                </p>
              </div>
            </div>

            {/* 1. LEETCODE SOLVED QUESTIONS STATS CARD */}
            <div className="clay-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center text-base">
                    ⚡
                  </div>
                  <div>
                    <h3 className="text-xs font-black text-[#2B124C] m-0">LeetCode Solved Problems</h3>
                    <span className="text-[10px] text-[#854F6C] font-semibold">
                      Contest Rating: {userProfile.contestRating} · {userProfile.globalRank}
                    </span>
                  </div>
                </div>
                <span className="text-sm font-black text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-lg">
                  {userProfile.leetcodeSolved} / 500
                </span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden flex">
                <div style={{ width: '37.5%' }} className="bg-emerald-500 h-full" title="Easy: 180" />
                <div style={{ width: '50%' }} className="bg-amber-500 h-full" title="Medium: 240" />
                <div style={{ width: '12.5%' }} className="bg-rose-500 h-full" title="Hard: 60" />
              </div>

              {/* Breakdown Grid */}
              <div className="grid grid-cols-3 gap-2 text-center pt-1">
                <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200">
                  <div className="text-xs font-black text-emerald-800">{userProfile.leetcodeEasy}</div>
                  <div className="text-[9px] font-bold text-emerald-600">Easy</div>
                </div>
                <div className="p-2 rounded-xl bg-amber-50 border border-amber-200">
                  <div className="text-xs font-black text-amber-800">{userProfile.leetcodeMed}</div>
                  <div className="text-[9px] font-bold text-amber-600">Medium</div>
                </div>
                <div className="p-2 rounded-xl bg-rose-50 border border-rose-200">
                  <div className="text-xs font-black text-rose-800">{userProfile.leetcodeHard}</div>
                  <div className="text-[9px] font-bold text-rose-600">Hard</div>
                </div>
              </div>
            </div>

            {/* 2. VOUCHERS EARNED HIGHLIGHTS */}
            <div className="clay-card-warm p-4 border-2 border-[#DFB6B2] space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Ticket className="w-4 h-4 text-[#522B5B]" />
                  <h3 className="font-black text-xs text-[#2B124C] m-0">Vouchers & Perks Earned</h3>
                </div>
                <button
                  onClick={() => setShowVouchersModal(true)}
                  className="text-[10px] font-black text-[#522B5B] hover:underline cursor-pointer"
                >
                  View All ({claimedVouchers.length + 3}) →
                </button>
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                <div
                  onClick={() => setShowVouchersModal(true)}
                  className="clay-card p-2.5 shrink-0 flex items-center gap-2 cursor-pointer min-w-[170px]"
                >
                  <VoucherBrandLogo brand="starbucks" emoji="☕" />
                  <div className="min-w-0">
                    <div className="text-[11px] font-black text-[#2B124C] truncate">Starbucks 40% Off</div>
                    <div className="text-[9px] font-mono text-emerald-700 font-bold">STARBUCKS-JAVA40</div>
                  </div>
                </div>

                <div
                  onClick={() => setShowVouchersModal(true)}
                  className="clay-card p-2.5 shrink-0 flex items-center gap-2 cursor-pointer min-w-[170px]"
                >
                  <VoucherBrandLogo brand="spotify" emoji="🎧" />
                  <div className="min-w-0">
                    <div className="text-[11px] font-black text-[#2B124C] truncate">Spotify Student Pass</div>
                    <div className="text-[9px] font-mono text-emerald-700 font-bold">SPOTIFY-LOFI-PASS</div>
                  </div>
                </div>

                <div
                  onClick={() => setShowVouchersModal(true)}
                  className="clay-card p-2.5 shrink-0 flex items-center gap-2 cursor-pointer min-w-[170px]"
                >
                  <VoucherBrandLogo brand="epson" emoji="🖨️" />
                  <div className="min-w-0">
                    <div className="text-[11px] font-black text-[#2B124C] truncate">Epson 50 Free Pages</div>
                    <div className="text-[9px] font-mono text-emerald-700 font-bold">EPSON-PRINT-FREE50</div>
                  </div>
                </div>
              </div>
            </div>

            {/* 3. HACKATHONS & COMPETITIONS */}
            <div className="clay-card p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-amber-500" />
                  <h3 className="font-black text-xs text-[#2B124C] m-0">Hackathons & Competitions</h3>
                </div>
                <span className="text-[10px] font-black text-[#854F6C]">3 Active</span>
              </div>

              <div className="space-y-2">
                {userProfile.hackathons.map((h, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-xl bg-white border border-[#DFB6B2] flex items-center justify-between"
                  >
                    <div>
                      <div className="font-black text-xs text-[#2B124C]">{h.name}</div>
                      <div className="text-[10px] text-[#854F6C] font-semibold">
                        {h.title} · <span className="text-[#522B5B] font-bold">{h.role}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 shrink-0">
                      {h.badge}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* 4. CONNECTED STUDY BUDDIES (CONNECTIONS BUDDY NAME & MANAGE) */}
            <div className="clay-card p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#522B5B]" />
                  <h3 className="font-black text-xs text-[#2B124C] m-0">Connected Study Buddies</h3>
                </div>
                <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  {peersList.filter((p) => p.isConnected).length} Connected
                </span>
              </div>

              <div className="space-y-2">
                {peersList.filter((p) => p.isConnected).length === 0 ? (
                  <div className="p-3 rounded-xl bg-white/60 text-center text-xs text-[#854F6C] font-bold">
                    No connected buddies yet. Explore the Buddy Feed to connect!
                  </div>
                ) : (
                  peersList
                    .filter((p) => p.isConnected)
                    .map((peer) => (
                      <div
                        key={peer.id}
                        className="p-2.5 rounded-xl bg-white border border-[#DFB6B2] flex items-center justify-between gap-2.5"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className={`w-10 h-10 rounded-full ${peer.avatarBg} flex items-center justify-center text-xl shrink-0 border border-slate-200`}>
                            {peer.avatarEmoji}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-1">
                              <span className="font-black text-xs text-[#2B124C] truncate">{peer.n}</span>
                              <CheckCircle2 className="w-3 h-3 text-sky-500 fill-sky-100 shrink-0" />
                            </div>
                            <span className="text-[10px] text-[#854F6C] block truncate">
                              {peer.college.split('(')[0]} · #{peer.sk[0]}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => {
                              setActiveDmPeer(peer);
                              setShowDirectMessagesModal(true);
                            }}
                            className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-lg cursor-pointer"
                          >
                            Chat 💬
                          </button>
                          <button
                            onClick={() => {
                              setPeersList((prev) =>
                                prev.map((p) => (p.id === peer.id ? { ...p, isConnected: false } : p))
                              );
                              showToast(`Removed ${peer.n.split(' ')[0]} from study buddies! 🤝`);
                            }}
                            className="p-1 rounded-lg text-rose-600 hover:bg-rose-50 border border-rose-200 cursor-pointer"
                            title={`Remove ${peer.n} from buddies`}
                          >
                            <UserX className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Floating 3D Clay Toast */}
      {toastMessage && (
        <div className="absolute left-4 right-4 bottom-22 z-50 animate-pop">
          <div className="clay-card-purple text-white text-xs font-bold px-4 py-3 shadow-2xl flex items-center gap-2.5 border border-[#DFB6B2]/40">
            <span className="text-base">🌸</span>
            <span className="flex-1 leading-snug">{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Booking Modal */}
      {selectedTutor && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card p-5 w-full max-w-sm space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-[#2B124C]">Book 1-on-1 Session</h3>
              <button onClick={() => setSelectedTutor(null)} className="p-1 rounded-full text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-2 text-xs">
              <p className="font-bold text-[#2B124C] m-0">Tutor: {selectedTutor.name} ({selectedTutor.year})</p>
              <p className="text-[#854F6C] m-0">Cost: {selectedTutor.hourlyPoints} Points / 1 Hour</p>
              <div>
                <label className="font-black text-[#2B124C] block mb-1">Pick Available Time Slot</label>
                <div className="space-y-1.5">
                  {selectedTutor.availableSlots.map((sl) => (
                    <button
                      key={sl}
                      onClick={() => setBookingSlot(sl)}
                      className={`w-full text-left p-2 rounded-xl text-xs font-bold transition-all ${
                        bookingSlot === sl ? 'clay-pill-btn-active' : 'clay-pill-btn'
                      }`}
                    >
                      {sl}
                    </button>
                  ))}
                </div>
              </div>
              <button
                onClick={handleConfirmBooking}
                className="w-full clay-pill-btn-active py-3 rounded-xl font-black text-xs mt-2"
              >
                Confirm & Deduct {selectedTutor.hourlyPoints} Points
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5-Hub 3D Clay Bottom Navigation Bar */}
      <nav className="px-3 pb-3 pt-1 shrink-0 z-40 bg-[#FBE4D8]/95 backdrop-blur-md">
        <div className="clay-card py-1.5 px-2 flex items-center justify-between shadow-lg">
          <button
            onClick={() => setHub('study')}
            className={`flex flex-col items-center justify-center flex-1 py-1 rounded-2xl cursor-pointer transition-all ${
              hub === 'study' ? 'scale-105' : 'opacity-60 hover:opacity-100'
            }`}
          >
            <div
              className={`w-10 h-7 rounded-xl flex items-center justify-center mb-0.5 text-sm transition-all ${
                hub === 'study' ? 'clay-pill-btn-active' : ''
              }`}
            >
              🧠
            </div>
            <span className={`text-[10px] font-black ${hub === 'study' ? 'text-[#2B124C]' : 'text-[#854F6C]'}`}>
              Study
            </span>
          </button>

          <button
            onClick={() => setHub('notes')}
            className={`flex flex-col items-center justify-center flex-1 py-1 rounded-2xl cursor-pointer transition-all ${
              hub === 'notes' ? 'scale-105' : 'opacity-60 hover:opacity-100'
            }`}
          >
            <div
              className={`w-10 h-7 rounded-xl flex items-center justify-center mb-0.5 text-sm transition-all ${
                hub === 'notes' ? 'clay-pill-btn-active' : ''
              }`}
            >
              📚
            </div>
            <span className={`text-[10px] font-black ${hub === 'notes' ? 'text-[#2B124C]' : 'text-[#854F6C]'}`}>
              Library
            </span>
          </button>

          <button
            onClick={() => setHub('feed')}
            className={`flex flex-col items-center justify-center flex-1 py-1 rounded-2xl cursor-pointer transition-all ${
              hub === 'feed' ? 'scale-105' : 'opacity-60 hover:opacity-100'
            }`}
          >
            <div
              className={`w-10 h-7 rounded-xl flex items-center justify-center mb-0.5 text-sm transition-all ${
                hub === 'feed' ? 'clay-pill-btn-active' : ''
              }`}
            >
              📅
            </div>
            <span className={`text-[10px] font-black ${hub === 'feed' ? 'text-[#2B124C]' : 'text-[#854F6C]'}`}>
              Feed
            </span>
          </button>

          <button
            onClick={() => setHub('community')}
            className={`flex flex-col items-center justify-center flex-1 py-1 rounded-2xl cursor-pointer transition-all ${
              hub === 'community' ? 'scale-105' : 'opacity-60 hover:opacity-100'
            }`}
          >
            <div
              className={`w-10 h-7 rounded-xl flex items-center justify-center mb-0.5 text-sm transition-all ${
                hub === 'community' ? 'clay-pill-btn-active' : ''
              }`}
            >
              💬
            </div>
            <span className={`text-[10px] font-black ${hub === 'community' ? 'text-[#2B124C]' : 'text-[#854F6C]'}`}>
              Talk
            </span>
          </button>

          <button
            onClick={() => setHub('profile')}
            className={`flex flex-col items-center justify-center flex-1 py-1 rounded-2xl cursor-pointer transition-all ${
              hub === 'profile' ? 'scale-105' : 'opacity-60 hover:opacity-100'
            }`}
          >
            <div
              className={`w-10 h-7 rounded-xl flex items-center justify-center mb-0.5 text-sm transition-all ${
                hub === 'profile' ? 'clay-pill-btn-active' : ''
              }`}
            >
              👤
            </div>
            <span className={`text-[10px] font-black ${hub === 'profile' ? 'text-[#2B124C]' : 'text-[#854F6C]'}`}>
              Profile
            </span>
          </button>
        </div>
      </nav>

      {/* Claimed Vouchers Wallet Modal */}
      {showVouchersModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-5 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3.5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Ticket className="w-5 h-5 text-[#522B5B]" />
                <h3 className="font-black text-sm text-[#2B124C]">My Campus Vouchers</h3>
              </div>
              <button
                onClick={() => setShowVouchersModal(false)}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-[#854F6C] font-semibold m-0">
              Show these voucher promo codes or barcodes at the university canteen, bookstore, or print shop to claim your perks!
            </p>

            <div className="space-y-2.5">
              {claimedVouchers.length === 0 ? (
                <div className="p-4 rounded-xl clay-inset-box text-center text-xs font-bold text-[#854F6C]">
                  No vouchers claimed yet! Study with the timer to earn sparks and unlock food & book discounts!
                </div>
              ) : (
                claimedVouchers.map((item) => (
                  <div key={item.id} className="p-3 rounded-xl bg-white border-2 border-emerald-300 shadow-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{item.voucher.iconEmoji}</span>
                        <div>
                          <div className="font-black text-xs text-[#2B124C]">{item.voucher.title}</div>
                          <div className="text-[10px] text-[#854F6C] font-semibold">{item.voucher.partner}</div>
                        </div>
                      </div>
                      <span className="text-[9px] font-black uppercase text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full">
                        {item.voucher.discount}
                      </span>
                    </div>

                    <div className="p-2 rounded-lg bg-slate-50 border border-dashed border-slate-300 flex items-center justify-between">
                      <div>
                        <div className="text-[9px] font-bold text-slate-400">PROMO CODE</div>
                        <div className="font-mono font-black text-xs text-[#2B124C]">{item.voucher.promoCode}</div>
                      </div>
                      <button
                        onClick={() => copyVoucherCode(item.voucher.promoCode)}
                        className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3 h-3" />
                        <span>{copiedCode === item.voucher.promoCode ? 'Copied!' : 'Copy'}</span>
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-[9px] font-bold text-[#854F6C]">
                      <span>{item.voucher.validity}</span>
                      <span>Claimed {item.claimedAt}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button
              onClick={() => setShowVouchersModal(false)}
              className="w-full py-2 rounded-xl clay-pill-btn-active font-black text-xs cursor-pointer"
            >
              Back to Study
            </button>
          </div>
        </div>
      )}

      {/* Instagram-Style Story Viewer Modal */}
      {activeStoryPeer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-4 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3.5 relative overflow-hidden shadow-2xl">
            {/* Story Top Timer Progress Bar */}
            <div className="w-full h-1 bg-white/40 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-amber-400 to-rose-500 rounded-full w-4/5 animate-pulse" />
            </div>

            {/* Story Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-11 h-11 rounded-full p-[2px] bg-gradient-to-tr from-[#FF5E62] via-[#FF9966] to-[#854F6C]">
                  <div className={`w-full h-full rounded-full ${activeStoryPeer.avatarBg} border-2 border-white flex items-center justify-center text-xl`}>
                    {activeStoryPeer.avatarEmoji}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-black text-sm text-[#2B124C]">{activeStoryPeer.n}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-sky-500 fill-sky-100" />
                  </div>
                  <span className="text-[10px] text-[#854F6C] font-semibold block">
                    {activeStoryPeer.username} · {activeStoryPeer.activeStory?.timeLeft || 'Live'}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setActiveStoryPeer(null)}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Story Main Body Card */}
            <div className="bg-gradient-to-br from-[#2B124C] to-[#522B5B] text-white p-4 rounded-2xl space-y-2.5 shadow-inner border border-white/20">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-black uppercase text-[#DFB6B2] bg-white/10 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse" />
                  <span>{activeStoryPeer.activeStory?.statusBadge || 'Library 📚'}</span>
                </span>
                <span className="text-[10px] font-bold text-[#FBE4D8]">
                  {activeStoryPeer.college.split('(')[0]}
                </span>
              </div>

              <h3 className="font-black text-base text-white leading-snug m-0">
                {activeStoryPeer.activeStory?.topic || activeStoryPeer.activity}
              </h3>

              <p className="text-xs text-[#DFB6B2] font-medium leading-relaxed m-0 italic bg-white/10 p-2.5 rounded-xl border border-white/10">
                "{activeStoryPeer.quote}"
              </p>

              <div className="flex items-center gap-1.5 pt-1">
                {activeStoryPeer.sk.map((s) => (
                  <span key={s} className="text-[9px] font-black px-2 py-0.5 rounded-md bg-white/20 text-[#FBE4D8]">
                    #{s}
                  </span>
                ))}
              </div>
            </div>

            {/* Quick Cheer Reactions */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase text-[#854F6C] block">Send Quick Study Cheer</span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { label: '🔥 Keep Going!', msg: `Cheered on ${activeStoryPeer.n.split(' ')[0]} with 🔥!` },
                  { label: '☕ Coffee Cheer', msg: `Sent virtual coffee to ${activeStoryPeer.n.split(' ')[0]}! ☕` },
                  { label: '🎧 Join Pod', msg: `Requested study pod with ${activeStoryPeer.n.split(' ')[0]}!` },
                ].map((cheer) => (
                  <button
                    key={cheer.label}
                    onClick={() => {
                      showToast(cheer.msg);
                      setActiveStoryPeer(null);
                    }}
                    className="clay-card py-2 px-1 text-[10px] font-black text-[#2B124C] hover:bg-white active:scale-95 transition-all text-center cursor-pointer"
                  >
                    {cheer.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Send Direct Message / Reply */}
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                placeholder={`Reply to ${activeStoryPeer.n.split(' ')[0]}...`}
                className="flex-1 text-xs font-medium text-[#2B124C] bg-white border border-[#DFB6B2] rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#854F6C]"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    showToast(`Message sent to ${activeStoryPeer.n.split(' ')[0]}! 📲`);
                    setActiveStoryPeer(null);
                  }
                }}
              />
              <button
                onClick={() => {
                  showToast(`Message sent to ${activeStoryPeer.n.split(' ')[0]}! 📲`);
                  setActiveStoryPeer(null);
                }}
                className="clay-pill-btn-active px-3 py-2 rounded-xl text-xs font-black cursor-pointer"
              >
                Send 💬
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Instagram-Style Activity / Notifications Modal */}
      {showActivityModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-4 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3 max-h-[85vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#DFB6B2]/40 pb-2">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
                <h3 className="font-black text-base text-[#2B124C] m-0">Activity</h3>
              </div>
              <button
                onClick={() => setShowActivityModal(false)}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Today Activity */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase text-[#854F6C] tracking-wide block">Today</span>
              
              <div className="p-2.5 rounded-2xl bg-white border border-[#DFB6B2] flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-lg shrink-0">
                  🌸
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-[#2B124C] leading-snug m-0">
                    <span className="font-black">Riya Sharma</span> liked your DSA Tree Notes and cheered on your study session!
                  </p>
                  <span className="text-[10px] text-[#854F6C] font-semibold">12m ago</span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-[#2B124C] text-[#DFB6B2] flex items-center justify-center text-xs font-bold shrink-0">
                  📚
                </div>
              </div>

              <div className="p-2.5 rounded-2xl bg-white border border-[#DFB6B2] flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-lg shrink-0">
                  🌿
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-[#2B124C] leading-snug m-0">
                    <span className="font-black">Aarav Patel</span> sent you a study wave: 👋 "Let’s prep for Flutter!"
                  </p>
                  <span className="text-[10px] text-[#854F6C] font-semibold">48m ago</span>
                </div>
                <button
                  onClick={() => {
                    showToast('Waved back at Aarav! 👋');
                  }}
                  className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-xl shrink-0 cursor-pointer"
                >
                  Wave 👋
                </button>
              </div>

              <div className="p-2.5 rounded-2xl bg-white border border-[#DFB6B2] flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-sky-100 flex items-center justify-center text-lg shrink-0">
                  ⚡
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-[#2B124C] leading-snug m-0">
                    <span className="font-black">Kabir Verma</span> confirmed your OS doubt review slot for 7:00 PM.
                  </p>
                  <span className="text-[10px] text-[#854F6C] font-semibold">2h ago</span>
                </div>
                <span className="text-[10px] font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 shrink-0">
                  Confirmed ✓
                </span>
              </div>
            </div>

            {/* This Week Activity */}
            <div className="space-y-2 pt-1">
              <span className="text-[10px] font-black uppercase text-[#854F6C] tracking-wide block">Earlier</span>

              <div className="p-2.5 rounded-2xl bg-white border border-[#DFB6B2] flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center text-lg shrink-0">
                  🏆
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-[#2B124C] leading-snug m-0">
                    <span className="font-black">SIH 2026 Team EduSphere</span> invited you to join their hackathon roster.
                  </p>
                  <span className="text-[10px] text-[#854F6C] font-semibold">1d ago</span>
                </div>
                <button
                  onClick={() => {
                    setHub('community');
                    setCommunitySubView('teams');
                    setShowActivityModal(false);
                    showToast('Navigating to Hackathon Teams!');
                  }}
                  className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-xl shrink-0 cursor-pointer"
                >
                  View Team
                </button>
              </div>
            </div>

            <button
              onClick={() => setShowActivityModal(false)}
              className="w-full clay-pill-btn-active py-2.5 rounded-xl font-black text-xs cursor-pointer mt-2"
            >
              Done
            </button>
          </div>
        </div>
      )}

      {/* Instagram-Style Direct Messages Modal */}
      {showDirectMessagesModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-4 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3 max-h-[85vh] overflow-y-auto shadow-2xl flex flex-col">
            {/* DM Header */}
            <div className="flex items-center justify-between border-b border-[#DFB6B2]/40 pb-2 shrink-0">
              <div className="flex items-center gap-2">
                {activeDmPeer && (
                  <button
                    onClick={() => setActiveDmPeer(null)}
                    className="p-1 rounded-lg text-[#2B124C] hover:bg-black/5 cursor-pointer font-black text-sm"
                  >
                    ←
                  </button>
                )}
                <div>
                  <h3 className="font-black text-base text-[#2B124C] m-0 leading-none">
                    {activeDmPeer ? activeDmPeer.n : 'Direct Messages'}
                  </h3>
                  <span className="text-[10px] text-[#854F6C] font-semibold block mt-0.5">
                    {activeDmPeer ? `${activeDmPeer.username} · Online` : 'Campus Peer Chats'}
                  </span>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowDirectMessagesModal(false);
                  setActiveDmPeer(null);
                }}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer shrink-0"
              >
                ✕
              </button>
            </div>

            {/* If no peer selected: Show Conversation List */}
            {!activeDmPeer ? (
              <div className="space-y-2 overflow-y-auto flex-1">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Search campus buddies..."
                    className="w-full text-xs font-medium text-[#2B124C] bg-white border border-[#DFB6B2] rounded-xl pl-8 pr-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#854F6C]"
                  />
                  <Search className="w-3.5 h-3.5 text-[#854F6C] absolute left-3 top-2.5" />
                </div>

                <div className="space-y-1.5 pt-1">
                  {peersList.map((peer) => {
                    const peerThreads = dmThreads[peer.id] || [
                      { sender: peer.n, text: `Hey! Studying ${peer.sk[0]} right now.`, time: 'Recently' },
                    ];
                    const lastMsg = peerThreads[peerThreads.length - 1];

                    return (
                      <div
                        key={peer.id}
                        onClick={() => setActiveDmPeer(peer)}
                        className="p-2.5 rounded-2xl bg-white hover:bg-slate-50 border border-[#DFB6B2] flex items-center gap-3 cursor-pointer transition-all active:scale-98"
                      >
                        <div className="relative">
                          <div className={`w-11 h-11 rounded-full ${peer.avatarBg} flex items-center justify-center text-xl border-2 border-[#DFB6B2]`}>
                            {peer.avatarEmoji}
                          </div>
                          <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#10B981] border-2 border-white" />
                        </div>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <span className="font-black text-xs text-[#2B124C] truncate">{peer.n}</span>
                            <span className="text-[9px] text-[#854F6C] font-semibold">{lastMsg.time}</span>
                          </div>
                          <p className="text-[11px] text-[#854F6C] font-medium truncate m-0">
                            {lastMsg.sender === 'You' ? 'You: ' : ''}{lastMsg.text}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* Active Conversation Thread */
              <div className="flex flex-col flex-1 space-y-3">
                {/* Peer Header Banner */}
                <div className="p-2.5 rounded-xl bg-white border border-[#DFB6B2] flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{activeDmPeer.avatarEmoji}</span>
                    <div>
                      <div className="text-xs font-black text-[#2B124C]">{activeDmPeer.college.split('(')[0]}</div>
                      <div className="text-[10px] text-[#854F6C] font-semibold">Specialty: #{activeDmPeer.sk.join(' #')}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setShowDirectMessagesModal(false);
                      setHub('study');
                      setStudySubView('room');
                      showToast(`Opened Whiteboard Study Pod with ${activeDmPeer.n.split(' ')[0]}! 🎧`);
                    }}
                    className="clay-pill-btn-active text-[10px] font-black px-2.5 py-1 rounded-lg cursor-pointer"
                  >
                    Start Pod 🎧
                  </button>
                </div>

                {/* Messages Bubbles */}
                <div className="space-y-2.5 flex-1 min-h-[160px] max-h-[260px] overflow-y-auto p-1">
                  {(dmThreads[activeDmPeer.id] || [
                    { sender: activeDmPeer.n, text: `Hey! Need any help with ${activeDmPeer.sk[0]}?`, time: '10:00 AM' },
                  ]).map((msg, idx) => {
                    const isMe = msg.sender === 'You';
                    return (
                      <div
                        key={idx}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[80%] p-2.5 rounded-2xl text-xs font-semibold leading-snug shadow-xs ${
                            isMe
                              ? 'bg-gradient-to-r from-[#854F6C] to-[#2B124C] text-white rounded-br-xs'
                              : 'bg-white text-[#2B124C] border border-[#DFB6B2] rounded-bl-xs'
                          }`}
                        >
                          {msg.text}
                        </div>
                        <span className="text-[9px] text-[#854F6C] font-bold px-1 mt-0.5">
                          {msg.time}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Send Input */}
                <div className="flex items-center gap-2 pt-1 border-t border-[#DFB6B2]/40">
                  <input
                    type="text"
                    value={dmInputText}
                    onChange={(e) => setDmInputText(e.target.value)}
                    placeholder={`Message ${activeDmPeer.n.split(' ')[0]}...`}
                    className="flex-1 text-xs font-medium text-[#2B124C] bg-white border border-[#DFB6B2] rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#854F6C]"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && dmInputText.trim()) {
                        const newMsg = { sender: 'You', text: dmInputText.trim(), time: 'Just now' };
                        setDmThreads((prev) => ({
                          ...prev,
                          [activeDmPeer.id]: [...(prev[activeDmPeer.id] || []), newMsg],
                        }));
                        setDmInputText('');
                        showToast(`Sent to ${activeDmPeer.n.split(' ')[0]}! 💬`);
                      }
                    }}
                  />
                  <button
                    onClick={() => {
                      if (!dmInputText.trim()) return;
                      const newMsg = { sender: 'You', text: dmInputText.trim(), time: 'Just now' };
                      setDmThreads((prev) => ({
                        ...prev,
                        [activeDmPeer.id]: [...(prev[activeDmPeer.id] || []), newMsg],
                      }));
                      setDmInputText('');
                      showToast(`Sent to ${activeDmPeer.n.split(' ')[0]}! 💬`);
                    }}
                    className="clay-pill-btn-active px-3.5 py-2.5 rounded-xl text-xs font-black cursor-pointer shrink-0"
                  >
                    Send 💬
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 1. SETTINGS MODAL (Upper Top Settings Icon Menu) */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-4 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3.5 max-h-[85vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#DFB6B2]/40 pb-2">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-[#2B124C]" />
                <h3 className="font-black text-base text-[#2B124C] m-0">Account & Settings</h3>
              </div>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Profile Glance in Settings */}
            <div className="p-3 rounded-2xl bg-white border border-[#DFB6B2] flex items-center gap-3">
              <div className="w-12 h-12 rounded-full p-0.5 bg-gradient-to-tr from-[#FF5E62] to-[#854F6C] shadow-sm shrink-0">
                <img
                  src={userProfile.avatar}
                  alt={userProfile.name}
                  className="w-full h-full object-cover rounded-full bg-[#190019] p-1"
                />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span className="font-black text-sm text-[#2B124C] truncate">{userProfile.name}</span>
                  <span className="text-[10px] text-sky-500 font-black">✓</span>
                </div>
                <span className="text-[11px] text-[#854F6C] font-semibold block truncate">
                  {userProfile.username} · {userProfile.college.split('(')[0]}
                </span>
              </div>
            </div>

            {/* Settings Options List */}
            <div className="space-y-2">
              {/* Option 1: Edit Profile */}
              <button
                onClick={() => {
                  setEditName(userProfile.name);
                  setEditBio(userProfile.bio);
                  setEditAvatar(userProfile.avatar);
                  setEditLeetCode(userProfile.leetcodeSolved);
                  setShowSettingsModal(false);
                  setShowEditProfileModal(true);
                }}
                className="w-full p-3 rounded-2xl bg-white hover:bg-slate-50 border border-[#DFB6B2] text-left flex items-center justify-between cursor-pointer transition-all active:scale-98 shadow-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-purple-50 text-[#522B5B] flex items-center justify-center text-base shrink-0">
                    <Edit3 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-black text-xs text-[#2B124C]">Edit Profile & Cartoon Avatar</div>
                    <div className="text-[10px] text-[#854F6C] font-medium">Update cartoon character, bio & LeetCode count</div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {/* Option 2: Remove Buddy */}
              <button
                onClick={() => {
                  setShowSettingsModal(false);
                  setShowRemoveBuddyModal(true);
                }}
                className="w-full p-3 rounded-2xl bg-white hover:bg-slate-50 border border-[#DFB6B2] text-left flex items-center justify-between cursor-pointer transition-all active:scale-98 shadow-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-base shrink-0">
                    <UserX className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-black text-xs text-[#2B124C]">Manage & Remove Buddies</div>
                    <div className="text-[10px] text-[#854F6C] font-medium">
                      {peersList.filter((p) => p.isConnected).length} connected study buddies
                    </div>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              {/* Option 3: Switch Demo Student Profile */}
              <div className="p-3 rounded-2xl bg-white border border-[#DFB6B2] space-y-2">
                <span className="text-[10px] font-black uppercase text-[#854F6C] block">
                  Switch Student Profile
                </span>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => {
                      setUserProfile((prev) => ({
                        ...prev,
                        name: 'Rahul Sharma',
                        username: '@rahul.dev',
                        avatar: '/assets/aistudio/image_bfa36e2d.png',
                        bio: 'DTU CSE \'27 | 480+ LeetCode Solved | Smart India Hackathon \'26 Finalist | 5 Vouchers Unlocked 🚀',
                      }));
                      setShowSettingsModal(false);
                      showToast('Switched to Rahul Sharma (3rd Year CSE)! 🎓');
                    }}
                    className={`p-2 rounded-xl text-[11px] font-black border transition-all cursor-pointer ${
                      userProfile.name === 'Rahul Sharma'
                        ? 'bg-[#2B124C] text-white border-[#2B124C]'
                        : 'bg-slate-50 text-[#2B124C] border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Rahul Sharma (DTU)
                  </button>

                  <button
                    onClick={() => {
                      setUserProfile((prev) => ({
                        ...prev,
                        name: 'Riya Sharma',
                        username: '@riya_codes',
                        avatar: '/assets/aistudio/image_1a4f2b80.png',
                        bio: 'DTU CSE \'27 | 450+ LeetCode problems solved | Graphs BFS/DFS specialist 🌸',
                      }));
                      setShowSettingsModal(false);
                      showToast('Switched to Riya Sharma profile! 🌸');
                    }}
                    className={`p-2 rounded-xl text-[11px] font-black border transition-all cursor-pointer ${
                      userProfile.name === 'Riya Sharma'
                        ? 'bg-[#2B124C] text-white border-[#2B124C]'
                        : 'bg-slate-50 text-[#2B124C] border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    Riya Sharma (DTU)
                  </button>
                </div>
              </div>

              {/* Option 4: Theme Toggle (Warm Light vs High-Contrast Dark) */}
              <div className="p-3.5 rounded-2xl bg-white border border-[#DFB6B2] space-y-2.5 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-indigo-50 text-[#522B5B] flex items-center justify-center text-xs">
                      {appTheme === 'dark' ? <Moon className="w-4 h-4 text-indigo-400" /> : <Sun className="w-4 h-4 text-amber-500" />}
                    </div>
                    <div>
                      <span className="text-[10px] font-black uppercase text-[#854F6C] block leading-none">
                        App Theme / Appearance
                      </span>
                      <span className="text-xs font-bold text-[#2B124C]">
                        {appTheme === 'dark' ? 'High-Contrast Dark' : 'Warm Light Clay'}
                      </span>
                    </div>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                    appTheme === 'dark'
                      ? 'bg-indigo-950 text-indigo-200 border border-indigo-700/60'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}>
                    {appTheme === 'dark' ? '🌙 Dark' : '☀️ Light'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => {
                      setAppTheme('warm');
                      showToast('Switched to Warm Light Theme ☀️');
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      appTheme === 'warm'
                        ? 'bg-gradient-to-r from-[#522B5B] to-[#2B124C] text-white border-[#2B124C] shadow-md ring-2 ring-[#DFB6B2]'
                        : 'bg-slate-50 text-[#2B124C] border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5" />
                    <span>Warm Light</span>
                  </button>

                  <button
                    onClick={() => {
                      setAppTheme('dark');
                      showToast('Switched to High-Contrast Dark Theme 🌙');
                    }}
                    className={`py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer border ${
                      appTheme === 'dark'
                        ? 'bg-gradient-to-r from-[#4F46E5] to-[#4338CA] text-white border-indigo-400 shadow-md ring-2 ring-indigo-300'
                        : 'bg-slate-50 text-[#2B124C] border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Moon className="w-3.5 h-3.5" />
                    <span>Dark Mode</span>
                  </button>
                </div>
              </div>

              {/* Option 5: Log Out */}
              <button
                onClick={() => {
                  setShowSettingsModal(false);
                  setIsLoggedIn(false);
                  showToast('Signed out to Welcome Screen! 👋');
                }}
                className="w-full p-3 rounded-2xl bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-black text-xs text-center flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-98"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out of CampusLoop</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. EDIT PROFILE MODAL */}
      {showEditProfileModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-4 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3.5 max-h-[88vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#DFB6B2]/40 pb-2">
              <div className="flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-[#2B124C]" />
                <h3 className="font-black text-base text-[#2B124C] m-0">Edit Profile</h3>
              </div>
              <button
                onClick={() => setShowEditProfileModal(false)}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Cartoon Avatar Picker */}
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase text-[#854F6C] block">
                Choose Cartoon Form Avatar
              </span>
              <div className="grid grid-cols-5 gap-2">
                {CARTOON_AVATARS.map((av) => (
                  <button
                    key={av.id}
                    onClick={() => setEditAvatar(av.src)}
                    className={`flex flex-col items-center gap-1 p-1 rounded-2xl border-2 transition-all cursor-pointer ${
                      editAvatar === av.src
                        ? 'border-[#2B124C] bg-white ring-2 ring-[#DFB6B2] scale-105'
                        : 'border-transparent bg-white/60 hover:bg-white'
                    }`}
                  >
                    <div className="w-11 h-11 rounded-full overflow-hidden bg-[#190019] p-0.5 border border-slate-200">
                      <img src={av.src} alt={av.name} className="w-full h-full object-cover" />
                    </div>
                    <span className="text-[8px] font-black text-[#2B124C] truncate max-w-full">
                      {av.emoji}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Form Fields */}
            <div className="space-y-3 text-left">
              <div>
                <label className="text-[10px] font-black uppercase text-[#854F6C] block mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full text-xs font-bold text-[#2B124C] bg-white border border-[#DFB6B2] rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#854F6C]"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-[#854F6C] block mb-1">
                  LeetCode Solved Questions
                </label>
                <input
                  type="number"
                  value={editLeetCode}
                  onChange={(e) => setEditLeetCode(Number(e.target.value) || 0)}
                  className="w-full text-xs font-bold text-[#2B124C] bg-white border border-[#DFB6B2] rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-[#854F6C]"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-[#854F6C] block mb-1">
                  Campus Bio & Hackathon Target
                </label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  className="w-full text-xs font-medium text-[#2B124C] bg-white border border-[#DFB6B2] rounded-xl p-2.5 focus:outline-none focus:ring-2 focus:ring-[#854F6C]"
                />
              </div>
            </div>

            {/* Save Button */}
            <button
              onClick={() => {
                setUserProfile((prev) => ({
                  ...prev,
                  name: editName,
                  bio: editBio,
                  avatar: editAvatar,
                  leetcodeSolved: editLeetCode,
                }));
                setShowEditProfileModal(false);
                showToast('Profile & Cartoon Avatar updated successfully! 🎨✨');
              }}
              className="w-full clay-pill-btn-active py-2.5 rounded-xl font-black text-xs cursor-pointer shadow-md"
            >
              Save Profile Changes ✓
            </button>
          </div>
        </div>
      )}

      {/* 3. MANAGE & REMOVE BUDDY MODAL */}
      {showRemoveBuddyModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="clay-card-warm p-4 w-full max-w-sm border-2 border-[#DFB6B2] space-y-3 max-h-[85vh] overflow-y-auto shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#DFB6B2]/40 pb-2">
              <div className="flex items-center gap-2">
                <UserX className="w-5 h-5 text-rose-500" />
                <h3 className="font-black text-base text-[#2B124C] m-0">Remove Buddy</h3>
              </div>
              <button
                onClick={() => setShowRemoveBuddyModal(false)}
                className="w-7 h-7 rounded-full clay-pill-btn flex items-center justify-center text-xs font-black cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-[11px] text-[#854F6C] font-semibold m-0">
              Manage your connected campus study buddies. Removing a buddy disconnects your shared streak & direct whiteboard notifications.
            </p>

            <div className="space-y-2 pt-1">
              {peersList.filter((p) => p.isConnected).length === 0 ? (
                <div className="p-4 rounded-xl bg-white border border-dashed border-[#DFB6B2] text-center space-y-2">
                  <span className="text-2xl block">🤝</span>
                  <div className="text-xs font-black text-[#2B124C]">No Active Buddies Connected</div>
                  <p className="text-[10px] text-[#854F6C] m-0">
                    Discover new peers in the Discovery Feed to start collaborative study sessions!
                  </p>
                  <button
                    onClick={() => {
                      setShowRemoveBuddyModal(false);
                      setHub('study');
                      setStudySubView('matcher');
                      setBuddyViewMode('feed');
                    }}
                    className="clay-pill-btn-active text-xs font-black px-3 py-1.5 rounded-xl cursor-pointer"
                  >
                    Go to Buddy Discovery Feed →
                  </button>
                </div>
              ) : (
                peersList
                  .filter((p) => p.isConnected)
                  .map((peer) => (
                    <div
                      key={peer.id}
                      className="p-3 rounded-2xl bg-white border border-[#DFB6B2] flex items-center justify-between gap-2.5 shadow-xs"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className={`w-11 h-11 rounded-full ${peer.avatarBg} flex items-center justify-center text-xl shrink-0 border border-slate-200`}>
                          {peer.avatarEmoji}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1">
                            <span className="font-black text-xs text-[#2B124C] truncate">{peer.n}</span>
                            <CheckCircle2 className="w-3.5 h-3.5 text-sky-500 fill-sky-100 shrink-0" />
                          </div>
                          <span className="text-[10px] text-[#854F6C] font-semibold block truncate">
                            {peer.college.split('(')[0]}
                          </span>
                          <span className="text-[9px] text-[#522B5B] font-bold block">
                            #{peer.sk.join(' #')}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setPeersList((prev) =>
                            prev.map((p) => (p.id === peer.id ? { ...p, isConnected: false } : p))
                          );
                          showToast(`Removed ${peer.n.split(' ')[0]} from study buddies! 🤝`);
                        }}
                        className="py-1.5 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs font-black cursor-pointer active:scale-95 transition-all flex items-center gap-1 shrink-0"
                      >
                        <UserX className="w-3.5 h-3.5" />
                        <span>Remove</span>
                      </button>
                    </div>
                  ))
              )}
            </div>

            <button
              onClick={() => setShowRemoveBuddyModal(false)}
              className="w-full clay-pill-btn-active py-2.5 rounded-xl font-black text-xs cursor-pointer mt-2"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
